export interface TestimonialItem {
  id: string;
  clientName: string;
  eventType: string;
  reviewText: string;
  rating: number;
  location: string;
  isSamplePlaceholder: boolean;
}

export const testimonials: TestimonialItem[] = [
  {
    id: "test-1",
    clientName: "Vikram & Sanya",
    eventType: "Wedding Photography & Film",
    location: "Hyderabad",
    rating: 5,
    isSamplePlaceholder: true,
    reviewText: "[Sample Review — To be replaced with client quote] Rahul and his team captured the genuine emotion of our wedding day so effortlessly. The candid shots and the teaser film made us relive every single smile.",
  },
  {
    id: "test-2",
    clientName: "Rohan M.",
    eventType: "Car Delivery Shoot & Reel",
    location: "Secunderabad",
    rating: 5,
    isSamplePlaceholder: true,
    reviewText: "[Sample Review — To be replaced with client quote] Bringing home my dream car was a huge milestone. Rahul's delivery shoot and the Instagram reel were top tier! Everyone in my circle was stunned by the quality.",
  },
  {
    id: "test-3",
    clientName: "Divya & Harsha",
    eventType: "Pre-Wedding & Engagement",
    location: "Telangana",
    rating: 5,
    isSamplePlaceholder: true,
    reviewText: "[Sample Review — To be replaced with client quote] Super comfortable in front of the camera thanks to Rahul's friendly guidance. The outdoor lighting and colors look like a movie scene. Highly recommended!",
  },
  {
    id: "test-4",
    clientName: "Pooja Reddy",
    eventType: "Birthday Celebration",
    location: "Hyderabad",
    rating: 5,
    isSamplePlaceholder: true,
    reviewText: "[Sample Review — To be replaced with client quote] Captured all the fun and decor details for my son's first birthday so beautifully. Punctual, polite, and very prompt with the edited photos.",
  },
];
