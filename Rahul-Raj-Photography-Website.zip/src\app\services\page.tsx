import Image from "next/image";
import Link from "next/link";
import { 
  Camera, 
  Film, 
  Calendar, 
  CheckCircle2, 
  ArrowRight, 
  Sparkles, 
  MessageCircle,
  HelpCircle
} from "lucide-react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import WhatsAppFloatingBtn from "@/components/WhatsAppFloatingBtn";
import CtaSection from "@/components/CtaSection";
import { services } from "@/data/services";
import { siteConfig } from "@/data/siteConfig";

export const metadata = {
  title: "Photography & Cinematography Services | Rahul Raj Photography",
  description: "Explore professional wedding photography, birthday films, car delivery shoots, pre-weddings, and corporate coverage by Rahul Raj Photography.",
};

export default function ServicesPage() {
  const whatsappUrl = `https://wa.me/${siteConfig.whatsappNumber}?text=${encodeURIComponent(
    "Hello Rahul Raj Photography, I am looking at your services page and would like to enquire about pricing and availability."
  )}`;

  return (
    <div className="min-h-screen bg-[#050505] text-white selection:bg-[#E50914] selection:text-white flex flex-col justify-between">
      <Navbar />

      {/* Header */}
      <section className="relative pt-36 pb-20 px-4 sm:px-6 lg:px-8 border-b border-[#1A1A1A] bg-gradient-to-b from-[#0F0F0F] to-[#050505]">
        <div className="max-w-5xl mx-auto text-center">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-[#161616] border border-[#2B2B2B] text-xs uppercase tracking-widest text-[#BDBDBD] mb-6">
            <Camera className="w-3.5 h-3.5 text-[#E50914]" />
            <span>Comprehensive Visual Coverage</span>
          </div>
          <h1 className="text-4xl sm:text-6xl font-serif font-normal text-white mb-6">
            Our Photography Services
          </h1>
          <p className="text-base sm:text-lg text-[#BDBDBD] font-light max-w-2xl mx-auto leading-relaxed">
            From royal multi-day weddings to exciting new car unveilings and intimate family portraits, we provide specialized artistic documentation for every occasion.
          </p>
        </div>
      </section>

      {/* Services List Section */}
      <section className="py-24 px-4 sm:px-6 lg:px-8 bg-[#050505]">
        <div className="max-w-7xl mx-auto space-y-24">
          {services.map((service, index) => {
            const isReversed = index % 2 === 1;
            return (
              <div
                key={service.id}
                id={service.id}
                className={`grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 items-center ${
                  isReversed ? "lg:flex-row-reverse" : ""
                }`}
              >
                {/* Visual Image */}
                <div className={`relative ${isReversed ? "lg:order-2" : ""}`}>
                  <div className="relative aspect-[4/3] rounded-2xl overflow-hidden border border-[#242424] shadow-2xl group">
                    <Image
                      src={service.coverImage}
                      alt={service.title}
                      fill
                      sizes="(max-width: 1024px) 100vw, 50vw"
                      className="object-cover group-hover:scale-105 transition-transform duration-700"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent opacity-60" />
                    
                    <div className="absolute bottom-4 left-4 right-4 flex items-center justify-between p-3.5 rounded-xl bg-black/75 backdrop-blur-md border border-white/10 text-xs">
                      <span className="text-[#BDBDBD]">Pricing Information:</span>
                      <span className="font-semibold text-[#E50914] uppercase tracking-wider">
                        {siteConfig.pricingNote}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Details */}
                <div className={`space-y-6 ${isReversed ? "lg:order-1" : ""}`}>
                  <div className="inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-widest text-[#E50914]">
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>Specialized Coverage</span>
                  </div>

                  <h2 className="text-2xl sm:text-4xl font-serif font-normal text-white">
                    {service.title}
                  </h2>

                  <p className="text-base text-[#D1D1D1] font-light leading-relaxed">
                    {service.shortDesc}
                  </p>

                  <p className="text-sm text-[#8E8E8E] leading-relaxed">
                    {service.description}
                  </p>

                  {/* Highlights list */}
                  <div className="space-y-2.5 pt-2">
                    <h4 className="text-xs uppercase font-semibold tracking-wider text-white">
                      What is Included:
                    </h4>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs text-[#BDBDBD]">
                      {service.highlights.map((highlight, i) => (
                        <div key={i} className="flex items-start gap-2">
                          <CheckCircle2 className="w-3.5 h-3.5 text-[#E50914] flex-shrink-0 mt-0.5" />
                          <span>{highlight}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="pt-4 flex flex-wrap items-center gap-4">
                    <Link
                      href={`/book?service=${encodeURIComponent(service.title)}`}
                      className="inline-flex items-center gap-2 px-6 py-3 rounded-full bg-[#E50914] text-white font-semibold text-xs uppercase tracking-wider hover:bg-[#C40812] transition-all shadow-lg shadow-[#E50914]/20"
                    >
                      <Calendar className="w-4 h-4" />
                      <span>Book This Service</span>
                    </Link>

                    <Link
                      href={`/portfolio?category=${service.categorySlug}`}
                      className="inline-flex items-center gap-2 px-6 py-3 rounded-full bg-[#121212] border border-[#2B2B2B] text-white hover:border-[#E50914] text-xs uppercase tracking-wider font-semibold transition-all"
                    >
                      <span>View Gallery</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </Link>

                    <a
                      href={`https://wa.me/${siteConfig.whatsappNumber}?text=${encodeURIComponent(
                        `Hello Rahul, I am interested in your "${service.title}" service. Please let me know the pricing and available dates.`
                      )}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#25D366] hover:underline"
                    >
                      <MessageCircle className="w-3.5 h-3.5" />
                      <span>Enquire on WhatsApp</span>
                    </a>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* FAQ / Clarification */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-[#090909] border-t border-[#1C1C1C]">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12">
            <HelpCircle className="w-6 h-6 text-[#E50914] mx-auto mb-2" />
            <h3 className="text-2xl font-serif text-white">Have a Unique Requirement?</h3>
            <p className="text-xs text-[#8E8E8E] mt-1">
              Every event has its own schedule, crew requirements, and visual style.
            </p>
          </div>

          <div className="p-8 rounded-2xl bg-[#111111] border border-[#222222] text-center space-y-4">
            <p className="text-sm text-[#BDBDBD] leading-relaxed">
              We customize packages based on your exact location, hours of coverage, multi-event ceremonies, and album preferences. Discussing your requirements personally allows Rahul to provide you with the most accurate, transparent quotation.
            </p>
            <div className="pt-2">
              <a
                href={whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 px-6 py-3 rounded-full bg-[#161616] border border-[#2E2E2E] text-white hover:border-[#25D366] hover:text-[#25D366] text-xs uppercase tracking-wider font-semibold transition-all"
              >
                <MessageCircle className="w-4 h-4 text-[#25D366]" />
                <span>Discuss Custom Requirements</span>
              </a>
            </div>
          </div>
        </div>
      </section>

      <CtaSection />
      <Footer />
      <WhatsAppFloatingBtn />
    </div>
  );
}
