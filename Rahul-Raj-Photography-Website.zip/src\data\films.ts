export interface FilmItem {
  id: string;
  title: string;
  category: string;
  categorySlug: string;
  duration: string;
  thumbnail: string;
  videoUrl?: string;
  description: string;
  isPlaceholder?: boolean;
}

export const films: FilmItem[] = [
  {
    id: "film-1",
    title: "Vows in Gold — Rahul & Priya Wedding Film",
    category: "Wedding Films",
    categorySlug: "weddings",
    duration: "4:32",
    thumbnail: "https://images.unsplash.com/photo-1519741497674-611481863552?auto=format&fit=crop&w=1200&q=80",
    description: "A cinematic wedding highlight documenting tears of happiness, grand rituals, and unforgettable family celebrations.",
    isPlaceholder: true,
  },
  {
    id: "film-2",
    title: "Eternal Sunrise — Arjun & Sneha Pre-Wedding Teaser",
    category: "Pre-Wedding Films",
    categorySlug: "pre-wedding",
    duration: "2:45",
    thumbnail: "https://images.unsplash.com/photo-1511285560929-80b456fea0bc?auto=format&fit=crop&w=1200&q=80",
    description: "Breathtaking drone visuals and gentle romance filmed against ancient stone pillars and golden sunsets.",
    isPlaceholder: true,
  },
  {
    id: "film-3",
    title: "Dream Beast Unveiled — Mercedes Delivery Film",
    category: "Car Delivery Videos",
    categorySlug: "car-delivery",
    duration: "1:15",
    thumbnail: "https://images.unsplash.com/photo-1617814076367-b759c7d7e738?auto=format&fit=crop&w=1200&q=80",
    description: "Dynamic automotive cinematography with slow-motion details, showroom unveil, and family handover celebration.",
    isPlaceholder: true,
  },
  {
    id: "film-4",
    title: "Joy & Confetti — Aarav's 1st Birthday Film",
    category: "Birthday Films",
    categorySlug: "birthday",
    duration: "3:10",
    thumbnail: "https://images.unsplash.com/photo-1530103862676-de8c9debad1d?auto=format&fit=crop&w=1200&q=80",
    description: "Heartwarming giggles, cake-smash moments, and cheerful family bonds filmed with vibrant cinematic warmth.",
    isPlaceholder: true,
  },
  {
    id: "film-5",
    title: "The Regal Night — Aditya & Pooja Reception Highlights",
    category: "Wedding Highlights",
    categorySlug: "reception",
    duration: "3:40",
    thumbnail: "https://images.unsplash.com/photo-1465495976277-4387d4b0b4c6?auto=format&fit=crop&w=1200&q=80",
    description: "High-energy stage entries, live musical performances, and family toast celebrations under chandelier lighting.",
    isPlaceholder: true,
  },
  {
    id: "film-6",
    title: "Thunder on Wheels — BMW M-Series Delivery Reel",
    category: "Car Delivery Videos",
    categorySlug: "car-delivery",
    duration: "0:58",
    thumbnail: "https://images.unsplash.com/photo-1503376780353-7e6692767b70?auto=format&fit=crop&w=1200&q=80",
    description: "Pumping soundtrack, exhaust roar, and the electric thrill of driving off the showroom floor.",
    isPlaceholder: true,
  },
];
