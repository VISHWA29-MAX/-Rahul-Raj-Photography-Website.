"use client";

import { useState } from "react";
import Link from "next/link";
import { 
  CheckCircle2, 
  Calendar, 
  MessageCircle, 
  Sparkles, 
  HelpCircle, 
  Layers,
  ArrowRight
} from "lucide-react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import WhatsAppFloatingBtn from "@/components/WhatsAppFloatingBtn";
import CtaSection from "@/components/CtaSection";
import { packages, PackageItem } from "@/data/packages";
import { siteConfig } from "@/data/siteConfig";

export default function PackagesPage() {
  const [selectedCategory, setSelectedCategory] = useState<string>("All");

  const categories = ["All", "Weddings", "Birthdays", "Car Delivery", "Other Events"];

  const filteredPackages = selectedCategory === "All"
    ? packages
    : packages.filter((p) => p.category === selectedCategory);

  return (
    <div className="min-h-screen bg-[#050505] text-white selection:bg-[#E50914] selection:text-white flex flex-col justify-between">
      <Navbar />

      {/* Header */}
      <section className="relative pt-36 pb-20 px-4 sm:px-6 lg:px-8 border-b border-[#1A1A1A] bg-gradient-to-b from-[#0F0F0F] to-[#050505]">
        <div className="max-w-5xl mx-auto text-center">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-[#161616] border border-[#2B2B2B] text-xs uppercase tracking-widest text-[#BDBDBD] mb-6">
            <Sparkles className="w-3.5 h-3.5 text-[#E50914]" />
            <span>Tailored Photography &amp; Film Plans</span>
          </div>
          <h1 className="text-4xl sm:text-6xl font-serif font-normal text-white mb-6">
            Packages &amp; Pricing
          </h1>
          <p className="text-base sm:text-lg text-[#BDBDBD] font-light max-w-2xl mx-auto leading-relaxed">
            Every celebration has a unique scale and story. Review our curated coverage options and contact Rahul directly for personalized pricing.
          </p>
        </div>
      </section>

      {/* Package Filter & Cards */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-[#050505]">
        <div className="max-w-7xl mx-auto">
          {/* Category Filter Pills */}
          <div className="flex flex-wrap items-center justify-center gap-2.5 mb-16">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-5 py-2.5 rounded-full text-xs font-semibold tracking-wider uppercase transition-all ${
                  selectedCategory === cat
                    ? "bg-[#E50914] text-white shadow-lg shadow-[#E50914]/20"
                    : "bg-[#111111] border border-[#222222] text-[#BDBDBD] hover:text-white hover:border-[#333333]"
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          {/* Pricing Card Notice */}
          <div className="max-w-2xl mx-auto mb-12 p-4 rounded-xl bg-[#111111] border border-[#262626] text-center text-xs text-[#9E9E9E]">
            <p>
              <strong className="text-white">Note on Pricing:</strong> We do not display fixed generic prices because every event differs in venue distance, duration, multi-day rituals, and album specifications. Click <strong className="text-[#E50914]">"Get a Custom Quote"</strong> to check availability.
            </p>
          </div>

          {/* Packages Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredPackages.map((pkg) => (
              <div
                key={pkg.id}
                className={`relative rounded-2xl p-7 bg-[#111111] border flex flex-col justify-between transition-all duration-300 hover:scale-[1.02] ${
                  pkg.recommended
                    ? "border-[#E50914] shadow-2xl shadow-[#E50914]/10 bg-gradient-to-b from-[#161212] to-[#111111]"
                    : "border-[#222222] hover:border-[#333333]"
                }`}
              >
                {/* Header Badge */}
                {pkg.badge && (
                  <span className="absolute -top-3 right-6 px-3 py-1 rounded-full bg-[#E50914] text-white text-[10px] uppercase font-bold tracking-wider shadow-md">
                    {pkg.badge}
                  </span>
                )}

                <div>
                  <span className="text-[11px] font-semibold uppercase tracking-wider text-[#E50914] block mb-1">
                    {pkg.category}
                  </span>
                  <h3 className="text-xl font-serif font-medium text-white mb-3">
                    {pkg.name}
                  </h3>
                  <p className="text-xs text-[#9E9E9E] leading-relaxed mb-6">
                    {pkg.shortDesc}
                  </p>

                  {/* Price Banner */}
                  <div className="p-4 rounded-xl bg-[#090909] border border-[#1F1F1F] text-center mb-6">
                    <span className="text-[10px] text-[#737373] uppercase tracking-widest block mb-0.5">
                      Investment
                    </span>
                    <span className="text-lg font-serif font-medium text-white tracking-wide">
                      {pkg.pricingLabel}
                    </span>
                  </div>

                  {/* Inclusions */}
                  <div className="space-y-3 mb-8">
                    <h4 className="text-xs uppercase tracking-wider font-semibold text-[#D1D1D1]">
                      Package Features:
                    </h4>
                    <ul className="space-y-2 text-xs text-[#BDBDBD]">
                      {pkg.inclusions.map((inc, i) => (
                        <li key={i} className="flex items-start gap-2.5">
                          <CheckCircle2 className="w-4 h-4 text-[#E50914] flex-shrink-0 mt-0.5" />
                          <span>{inc}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>

                {/* Buttons */}
                <div className="pt-4 border-t border-[#1C1C1C] flex flex-col gap-2.5">
                  <Link
                    href={`/book?package=${encodeURIComponent(pkg.name)}`}
                    className="w-full py-3 rounded-xl bg-[#E50914] text-white text-center font-bold text-xs uppercase tracking-wider hover:bg-[#C40812] transition-colors shadow-lg shadow-[#E50914]/20"
                  >
                    Get a Custom Quote
                  </Link>

                  <a
                    href={`https://wa.me/${siteConfig.whatsappNumber}?text=${encodeURIComponent(
                      `Hello Rahul, I am interested in the "${pkg.name}" (${pkg.category}) package. Please let me know your pricing and availability.`
                    )}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-full py-2.5 rounded-xl bg-[#161616] border border-[#262626] text-[#25D366] text-center font-semibold text-xs uppercase tracking-wider hover:border-[#25D366] transition-colors flex items-center justify-center gap-2"
                  >
                    <MessageCircle className="w-3.5 h-3.5" />
                    <span>Inquire via WhatsApp</span>
                  </a>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Multi-day custom wedding quote callout */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 bg-[#080808] border-t border-[#1C1C1C]">
        <div className="max-w-4xl mx-auto p-8 rounded-2xl bg-[#111111] border border-[#242424] flex flex-col md:flex-row items-center justify-between gap-6">
          <div>
            <h3 className="text-xl font-serif text-white mb-2">
              Planning a Destination or Multi-Day Wedding?
            </h3>
            <p className="text-xs text-[#8E8E8E] max-w-lg">
              We design custom coverage itineraries including drone cinematography, pre-wedding teasers, luxury hardbound photobooks, and dedicated crew sizes tailored to your celebrations.
            </p>
          </div>
          <Link
            href="/book"
            className="flex-shrink-0 inline-flex items-center gap-2 px-6 py-3 rounded-full bg-[#E50914] text-white text-xs uppercase font-bold tracking-wider hover:bg-[#C40812] transition-colors"
          >
            <span>Request Custom Plan</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </Link>
        </div>
      </section>

      <CtaSection />
      <Footer />
      <WhatsAppFloatingBtn />
    </div>
  );
}
