export const siteConfig = {
  name: "Rahul Raj Photography",
  tagline: "Every Moment Deserves To Be Remembered",
  shortDesc: "Capturing your beautiful moments through professional photography and cinematic storytelling across India and beyond.",
  instagramUrl: "https://www.instagram.com/rahul_raj_photography_world/",
  instagramHandle: "@rahul_raj_photography_world",
  // Configurable contact details (to be edited by Rahul)
  phone: "+91 98765 43210", // Placeholder - to be updated with Rahul's real number
  whatsappNumber: "919876543210", // Placeholder without symbols for WhatsApp API
  email: "contact@rahulrajphotography.com", // Placeholder
  address: "Hyderabad, Telangana, India",
  serviceArea: "Available for Photography & Cinematic Projects Across India and Beyond",
  pricingNote: "Contact for Price",
  logo: {
    dark: "/logo/logo.svg",
    light: "/logo/rahul-raj-photography-logo-4-transparent-for-light-pages.png",
    white: "/logo/rahul-raj-photography-logo-5-all-white-transparent.svg",
  },
  social: {
    instagram: "https://www.instagram.com/rahul_raj_photography_world/",
    youtube: "#",
    facebook: "#",
  }
};
