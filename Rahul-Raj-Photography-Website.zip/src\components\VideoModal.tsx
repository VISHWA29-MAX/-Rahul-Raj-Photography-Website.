"use client";

import { useEffect } from "react";
import { X, Film, Sparkles } from "lucide-react";
import { FilmItem } from "@/data/films";

interface VideoModalProps {
  film: FilmItem | null;
  onClose: () => void;
}

export default function VideoModal({ film, onClose }: VideoModalProps) {
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    if (film) {
      document.body.style.overflow = "hidden";
      window.addEventListener("keydown", handleKeyDown);
    }
    return () => {
      document.body.style.overflow = "unset";
      window.removeEventListener("keydown", handleKeyDown);
    };
  }, [film, onClose]);

  if (!film) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label={film.title}
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/90 backdrop-blur-md p-4 sm:p-6"
    >
      <div 
        className="relative w-full max-w-4xl bg-[#111111] rounded-2xl border border-[#2A2A2A] overflow-hidden shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between p-4 sm:p-5 border-b border-[#222222]">
          <div className="flex items-center gap-3">
            <span className="p-2 rounded-lg bg-[#E50914]/10 text-[#E50914]">
              <Film className="w-5 h-5" />
            </span>
            <div>
              <h3 className="text-white font-medium text-base sm:text-lg">{film.title}</h3>
              <p className="text-xs text-[#9E9E9E]">{film.category} • Duration {film.duration}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-full text-[#BDBDBD] hover:text-white hover:bg-[#222222] transition-colors"
            aria-label="Close video player"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Cinematic Video Player Container */}
        <div className="relative aspect-video bg-black flex items-center justify-center overflow-hidden">
          {film.videoUrl ? (
            <video
              src={film.videoUrl}
              controls
              autoPlay
              className="w-full h-full object-contain"
            />
          ) : (
            <div className="relative w-full h-full">
              {/* Background preview image */}
              <img
                src={film.thumbnail}
                alt={film.title}
                className="w-full h-full object-cover opacity-40 filter blur-sm"
              />
              <div className="absolute inset-0 flex flex-col items-center justify-center p-6 text-center bg-black/60">
                <div className="w-16 h-16 rounded-full bg-[#E50914]/20 border border-[#E50914] flex items-center justify-center text-white mb-4 animate-pulse">
                  <Film className="w-7 h-7 text-[#E50914]" />
                </div>
                <h4 className="text-xl font-serif font-medium text-white mb-2">{film.title}</h4>
                <p className="text-sm text-[#BDBDBD] max-w-md mb-4">{film.description}</p>
                <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-[#1A1A1A] border border-[#333333] text-xs text-[#9E9E9E]">
                  <Sparkles className="w-3.5 h-3.5 text-[#E50914]" />
                  <span>Cinematic Video Showcase Demo Preview</span>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer info */}
        <div className="p-4 sm:p-5 bg-[#0C0C0C] flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-[#737373]">
          <p>Filmed &amp; produced by Rahul Raj Photography</p>
          <a
            href="/book"
            className="text-[#E50914] hover:underline font-medium"
          >
            Enquire about booking this cinematic coverage &rarr;
          </a>
        </div>
      </div>
    </div>
  );
}
