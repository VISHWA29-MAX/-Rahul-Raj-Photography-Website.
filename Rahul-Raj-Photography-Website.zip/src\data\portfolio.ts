export interface PortfolioProject {
  id: string;
  title: string;
  slug: string;
  category: string;
  categorySlug: string;
  location: string;
  coverImage: string;
  featured: boolean;
  description: string;
  images: string[];
  isPlaceholder?: boolean;
}

export const portfolioProjects: PortfolioProject[] = [
  {
    id: "proj-1",
    title: "Rahul & Priya — Royal Wedding Celebration",
    slug: "rahul-priya-royal-wedding",
    category: "Wedding Photography",
    categorySlug: "weddings",
    location: "Hyderabad, Telangana",
    featured: true,
    isPlaceholder: true,
    description: "A breathtaking traditional celebration filled with sacred mantras, golden varmala moments, and joyous candid smiles amidst vibrant floral decor.",
    coverImage: "https://images.unsplash.com/photo-1519741497674-611481863552?auto=format&fit=crop&w=1200&q=80",
    images: [
      "https://images.unsplash.com/photo-1519741497674-611481863552?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1583939003579-730e3918a45a?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1606800052052-a08af7148866?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1511285560929-80b456fea0bc?auto=format&fit=crop&w=1200&q=80",
    ],
  },
  {
    id: "proj-2",
    title: "Arjun & Sneha — Heritage Pre-Wedding Tale",
    slug: "arjun-sneha-pre-wedding",
    category: "Pre-Wedding Photography",
    categorySlug: "pre-wedding",
    location: "Fort Grand & Lakeview, Telangana",
    featured: true,
    isPlaceholder: true,
    description: "An enchanting pre-wedding love story filmed at sunrise with regal architectural arches and soft golden-hour reflections.",
    coverImage: "https://images.unsplash.com/photo-1511285560929-80b456fea0bc?auto=format&fit=crop&w=1200&q=80",
    images: [
      "https://images.unsplash.com/photo-1511285560929-80b456fea0bc?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1465495976277-4387d4b0b4c6?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1515934751635-c81c6bc9a2d8?auto=format&fit=crop&w=1200&q=80",
    ],
  },
  {
    id: "proj-3",
    title: "Karan's Dream Machine — Mercedes Delivery",
    slug: "karans-mercedes-delivery",
    category: "Car Delivery Photography",
    categorySlug: "car-delivery",
    location: "Luxury Showroom, Hyderabad",
    featured: true,
    isPlaceholder: true,
    description: "An emotional celebration marking the arrival of a new luxury vehicle with key handover, family blessings, and cinematic automotive angles.",
    coverImage: "https://images.unsplash.com/photo-1617814076367-b759c7d7e738?auto=format&fit=crop&w=1200&q=80",
    images: [
      "https://images.unsplash.com/photo-1617814076367-b759c7d7e738?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1503376780353-7e6692767b70?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1552519507-da3b142c6e3d?auto=format&fit=crop&w=1200&q=80",
    ],
  },
  {
    id: "proj-4",
    title: "Aarav's 1st Birthday — Jungle Safari Theme",
    slug: "aaravs-first-birthday",
    category: "Birthday Events",
    categorySlug: "birthday",
    location: "Novotel, Hyderabad",
    featured: true,
    isPlaceholder: true,
    description: "A vibrant 1st birthday milestone filled with cute baby expressions, balloon installations, cheerful family laughter, and cake smash antics.",
    coverImage: "https://images.unsplash.com/photo-1530103862676-de8c9debad1d?auto=format&fit=crop&w=1200&q=80",
    images: [
      "https://images.unsplash.com/photo-1530103862676-de8c9debad1d?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1513151233558-d860c5398176?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1519689680058-324335c77eba?auto=format&fit=crop&w=1200&q=80",
    ],
  },
  {
    id: "proj-5",
    title: "Aditya & Pooja — Grand Reception Gala",
    slug: "aditya-pooja-grand-reception",
    category: "Reception",
    categorySlug: "reception",
    location: "ITC Kohenur, Hyderabad",
    featured: false,
    isPlaceholder: true,
    description: "An evening of elegance, crystal chandeliers, royal stage entries, and lively guest celebrations.",
    coverImage: "https://images.unsplash.com/photo-1465495976277-4387d4b0b4c6?auto=format&fit=crop&w=1200&q=80",
    images: [
      "https://images.unsplash.com/photo-1465495976277-4387d4b0b4c6?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1519741497674-611481863552?auto=format&fit=crop&w=1200&q=80",
    ],
  },
  {
    id: "proj-6",
    title: "Ananya — Golden Hour Maternity Portraiture",
    slug: "ananya-maternity-portraiture",
    category: "Maternity",
    categorySlug: "maternity",
    location: "Botanical Gardens, Hyderabad",
    featured: false,
    isPlaceholder: true,
    description: "A tender golden-hour maternity session celebrating motherhood, unconditional love, and glowing anticipation.",
    coverImage: "https://images.unsplash.com/photo-1555252333-9f8e92e65df9?auto=format&fit=crop&w=1200&q=80",
    images: [
      "https://images.unsplash.com/photo-1555252333-9f8e92e65df9?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1511895426328-dc8714191300?auto=format&fit=crop&w=1200&q=80",
    ],
  },
  {
    id: "proj-7",
    title: "BMW M-Series Delivery Celebration",
    slug: "bmw-m-series-delivery",
    category: "Car Delivery Photography",
    categorySlug: "car-delivery",
    location: "KUN Exclusive, Hyderabad",
    featured: false,
    isPlaceholder: true,
    description: "Showroom unveil and high-energy celebration for the new BMW sports machine with family members.",
    coverImage: "https://images.unsplash.com/photo-1503376780353-7e6692767b70?auto=format&fit=crop&w=1200&q=80",
    images: [
      "https://images.unsplash.com/photo-1503376780353-7e6692767b70?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1617814076367-b759c7d7e738?auto=format&fit=crop&w=1200&q=80",
    ],
  },
  {
    id: "proj-8",
    title: "Tech Summit Global Gala — Corporate Conference",
    slug: "tech-summit-global-gala",
    category: "Corporate Events",
    categorySlug: "corporate",
    location: "HICC Novotel, Hyderabad",
    featured: false,
    isPlaceholder: true,
    description: "Complete media coverage for international technology conference, keynotes, award ceremonies, and network banquet.",
    coverImage: "https://images.unsplash.com/photo-1511578314322-379afb476865?auto=format&fit=crop&w=1200&q=80",
    images: [
      "https://images.unsplash.com/photo-1511578314322-379afb476865?auto=format&fit=crop&w=1200&q=80",
      "https://images.unsplash.com/photo-1511895426328-dc8714191300?auto=format&fit=crop&w=1200&q=80",
    ],
  },
];
