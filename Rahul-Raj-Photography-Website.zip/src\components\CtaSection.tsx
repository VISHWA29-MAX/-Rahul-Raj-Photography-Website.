import Link from "next/link";
import { Calendar, MessageCircle, Sparkles } from "lucide-react";
import { siteConfig } from "@/data/siteConfig";

interface CtaSectionProps {
  title?: string;
  subtitle?: string;
}

export default function CtaSection({
  title = "LET'S MAKE YOUR SPECIAL MOMENTS UNFORGETTABLE.",
  subtitle = "Whether it's a grand royal wedding, a romantic pre-wedding story, a cheerful birthday celebration, or your proud new car delivery — we are ready to preserve your story across India and worldwide.",
}: CtaSectionProps) {
  const whatsappUrl = `https://wa.me/${siteConfig.whatsappNumber}?text=${encodeURIComponent(
    "Hello Rahul Raj Photography, I am planning an event and would like to check your availability and get a quote."
  )}`;

  return (
    <section className="relative py-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-b from-[#0A0A0A] to-[#050505] border-t border-[#1F1F1F] overflow-hidden">
      {/* Background ambient lighting */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[350px] bg-[#E50914]/10 blur-[140px] pointer-events-none rounded-full"></div>

      <div className="max-w-4xl mx-auto text-center relative z-10">
        <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-[#141414] border border-[#2B2B2B] text-xs uppercase tracking-widest text-[#BDBDBD] mb-6">
          <Sparkles className="w-3.5 h-3.5 text-[#E50914]" />
          <span>Bookings Open Pan-India &amp; Internationally</span>
        </div>

        <h2 className="text-3xl sm:text-5xl font-serif font-medium tracking-tight text-white mb-6 leading-tight">
          {title}
        </h2>

        <p className="text-base sm:text-lg text-[#BDBDBD] font-light max-w-2xl mx-auto mb-10 leading-relaxed">
          {subtitle}
        </p>

        <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
          <Link
            href="/book"
            className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-8 py-4 rounded-full bg-[#E50914] text-white font-bold text-sm uppercase tracking-wider hover:bg-[#C40812] transition-all shadow-xl shadow-[#E50914]/25 hover:shadow-[#E50914]/40"
          >
            <Calendar className="w-4 h-4" />
            <span>Book Your Event</span>
          </Link>

          <a
            href={whatsappUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-8 py-4 rounded-full bg-[#111111] border border-[#2E2E2E] text-white font-semibold text-sm uppercase tracking-wider hover:border-[#25D366] hover:text-[#25D366] transition-all"
          >
            <MessageCircle className="w-4 h-4 text-[#25D366]" />
            <span>Chat on WhatsApp</span>
          </a>
        </div>
      </div>
    </section>
  );
}
