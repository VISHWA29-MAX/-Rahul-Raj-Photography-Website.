export interface ServiceItem {
  id: string;
  title: string;
  categorySlug: string;
  shortDesc: string;
  description: string;
  coverImage: string;
  highlights: string[];
}

export const services: ServiceItem[] = [
  {
    id: "wedding-traditional-candid",
    title: "Traditional & Candid Wedding Photography",
    categorySlug: "weddings",
    shortDesc: "A seamless blend of sacred ceremonial coverage and raw, spontaneous emotional candid portraits.",
    description: "Our wedding coverage captures both the grandeur of traditional rituals and the intimate, unscripted candid emotions. Every prayer, smile, garland exchange, and tear of happiness is frozen in high-resolution clarity.",
    coverImage: "https://images.unsplash.com/photo-1519741497674-611481863552?auto=format&fit=crop&w=1200&q=80",
    highlights: [
      "Traditional stage & ritual photography",
      "Artistic candid photography capturing true emotions",
      "High-end bridal and groom solo portraits",
      "Family & guest group photo sessions",
      "Full high-resolution edited photo gallery",
    ],
  },
  {
    id: "full-wedding-packages",
    title: "Full Marriage Coverage & Drone Cinematography",
    categorySlug: "full-wedding-packages",
    shortDesc: "Complete multi-event coverage with multi-camera setup, aerial drone shots, and luxury wedding films.",
    description: "From Haldi and Mehendi to Sangeet, Wedding, and Reception, our complete team provides multi-angle photo and cinematic video production with aerial drone coverage.",
    coverImage: "https://images.unsplash.com/photo-1583939003579-730e3918a45a?auto=format&fit=crop&w=1200&q=80",
    highlights: [
      "Multi-day coverage (Haldi, Mehendi, Sangeet, Wedding, Reception)",
      "4K Cinematic Wedding Film + Teaser Trailer + Traditional Full Video",
      "Aerial Drone video coverage (subject to permissions)",
      "Premium handcrafted photobook albums",
      "Same-day teaser edits for social media",
    ],
  },
  {
    id: "pre-wedding-shoot",
    title: "Cinematic Pre-Wedding Shoots",
    categorySlug: "pre-wedding",
    shortDesc: "Romantic couple storytelling at handpicked locations with creative concepts and drone films.",
    description: "We help couples celebrate their unique love story in picturesque outdoor locations, resorts, or historical landmarks, creating memories before the big day arrives.",
    coverImage: "https://images.unsplash.com/photo-1511285560929-80b456fea0bc?auto=format&fit=crop&w=1200&q=80",
    highlights: [
      "Multiple outfit & location changes",
      "Cinematic couple love-story video teaser",
      "Posing guidance for natural, relaxed chemistry",
      "Golden hour & sunset landscape framing",
      "Optimized photos for wedding invitations & digital screens",
    ],
  },
  {
    id: "birthday-films",
    title: "Birthday Photography & Cinematic Films",
    categorySlug: "birthday",
    shortDesc: "Lively event photography, thematic decor shots, cake-cutting highlights, and social reels.",
    description: "Make milestone birthdays unforgettable! We document every cheerful moment, the excitement of children, cake cutting, family interactions, and generate dynamic Instagram reels.",
    coverImage: "https://images.unsplash.com/photo-1530103862676-de8c9debad1d?auto=format&fit=crop&w=1200&q=80",
    highlights: [
      "Theme decor, stage, and detail photography",
      "Cake cutting and celebratory candid moments",
      "Cinematic birthday highlight video film",
      "Social media ready 9:16 vertical reels",
      "High-res family portrait sessions",
    ],
  },
  {
    id: "car-delivery-films",
    title: "Car Delivery Photography & Cinematic Reels",
    categorySlug: "car-delivery",
    shortDesc: "Commemorate bringing your dream machine home with showroom unveilings, family pride, and dynamic reels.",
    description: "Taking delivery of a new vehicle is a milestone moment of accomplishment. We provide dedicated photography and cinematic videography at the dealership, capturing the unveil, key handover, family blessings, and first drive.",
    coverImage: "https://images.unsplash.com/photo-1617814076367-b759c7d7e738?auto=format&fit=crop&w=1200&q=80",
    highlights: [
      "Showroom unveiling and ribbon cutting coverage",
      "Key handover ceremony and family blessing portraits",
      "Cinematic automotive angles and slow-motion video captures",
      "High-impact Instagram reels with cinematic music",
      "Same-day or 24-hour turnaround for quick social sharing",
    ],
  },
  {
    id: "maternity-baby",
    title: "Maternity & Newborn Baby Photoshoots",
    categorySlug: "maternity",
    shortDesc: "Tender, artistic maternity sessions and gentle, safe baby portraits capturing new beginnings.",
    description: "Celebrate the magic of expecting a child and welcoming a newborn into the world. Our gentle sessions prioritize comfort, safety, and natural glowing warmth.",
    coverImage: "https://images.unsplash.com/photo-1555252333-9f8e92e65df9?auto=format&fit=crop&w=1200&q=80",
    highlights: [
      "Comfortable indoor studio or gentle outdoor golden hour",
      "Safe and sanitized props for newborn setups",
      "Couple & mother-focused aesthetic styling",
      "Gentle lighting designed to accentuate warmth",
      "Delicate color grading and retouching",
    ],
  },
  {
    id: "corporate-events",
    title: "Corporate Events & Brand Shoots",
    categorySlug: "corporate",
    shortDesc: "Sharp, executive coverage for conferences, business summits, product launches, and award nights.",
    description: "Professional media coverage for corporate conventions, leadership summits, gala dinners, and company milestone celebrations with rapid digital delivery.",
    coverImage: "https://images.unsplash.com/photo-1511578314322-379afb476865?auto=format&fit=crop&w=1200&q=80",
    highlights: [
      "Keynote speaker & panel session coverage",
      "Audience engagement and atmosphere captures",
      "Executive and team leadership group headshots",
      "Fast turnaround for press releases & PR",
      "Event recap video highlights",
    ],
  },
];
