import Image from "next/image";
import Link from "next/link";
import { 
  Camera, 
  Film, 
  Sparkles, 
  Calendar, 
  ArrowRight, 
  MapPin, 
  Heart, 
  CheckCircle2, 
  Eye, 
  Layers, 
  MessageCircle 
} from "lucide-react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import WhatsAppFloatingBtn from "@/components/WhatsAppFloatingBtn";
import CtaSection from "@/components/CtaSection";
import { siteConfig } from "@/data/siteConfig";

export const metadata = {
  title: "About Us | Rahul Raj Photography",
  description: "Learn more about Rahul Raj Photography, our storytelling philosophy, approach to weddings, birthdays, car deliveries, and cinematic films.",
};

export default function AboutPage() {
  const whatsappUrl = `https://wa.me/${siteConfig.whatsappNumber}?text=${encodeURIComponent(
    "Hello Rahul, I read about your work on your website and would like to discuss photography coverage for my upcoming event."
  )}`;

  return (
    <div className="min-h-screen bg-[#050505] text-white selection:bg-[#E50914] selection:text-white flex flex-col justify-between">
      <Navbar />

      {/* Header Banner */}
      <section className="relative pt-36 pb-20 px-4 sm:px-6 lg:px-8 border-b border-[#1A1A1A] bg-gradient-to-b from-[#0F0F0F] to-[#050505]">
        <div className="max-w-5xl mx-auto text-center">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-[#161616] border border-[#2B2B2B] text-xs uppercase tracking-widest text-[#BDBDBD] mb-6">
            <Sparkles className="w-3.5 h-3.5 text-[#E50914]" />
            <span>Behind The Lens</span>
          </div>
          <h1 className="text-4xl sm:text-6xl font-serif font-normal text-white mb-6">
            About Rahul Raj Photography
          </h1>
          <p className="text-base sm:text-lg text-[#BDBDBD] font-light max-w-2xl mx-auto leading-relaxed">
            Preserving life’s most profound emotions, celebrations, and achievements through an artistic blend of fine-art photography and cinematic film.
          </p>
        </div>
      </section>

      {/* Brand Story Section */}
      <section className="py-24 px-4 sm:px-6 lg:px-8 bg-[#050505]">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 items-center">
            {/* Visual Mosaic */}
            <div className="relative">
              <div className="relative aspect-[4/5] rounded-2xl overflow-hidden border border-[#242424] shadow-2xl">
                <Image
                  src="https://images.unsplash.com/photo-1511285560929-80b456fea0bc?auto=format&fit=crop&w=1200&q=80"
                  alt="Rahul Raj Story"
                  fill
                  className="object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent opacity-70" />
                <div className="absolute bottom-6 left-6 right-6 p-5 rounded-xl bg-[#0D0D0D]/90 backdrop-blur-md border border-[#262626]">
                  <p className="text-xs uppercase tracking-widest text-[#E50914] font-semibold mb-1">
                    Visual Storyteller
                  </p>
                  <p className="text-sm text-white font-serif">
                    “A photograph is a pause button for life’s most fleeting moments.”
                  </p>
                </div>
              </div>
            </div>

            {/* Narrative Content */}
            <div className="space-y-6">
              <div className="inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-widest text-[#E50914]">
                <Heart className="w-4 h-4" />
                <span>Our Heritage &amp; Passion</span>
              </div>

              <h2 className="text-3xl sm:text-4xl font-serif font-normal text-white leading-tight">
                Crafting Timeless Heirlooms for Generations
              </h2>

              <p className="text-base text-[#BDBDBD] font-light leading-relaxed">
                Founded with a deep love for honest emotion and visual aesthetics, Rahul Raj Photography has evolved into a premier destination for couples, families, and automobile enthusiasts who seek meaningful, cinema-grade documentation.
              </p>

              <p className="text-sm text-[#8E8E8E] leading-relaxed">
                We believe that great photography transcends expensive equipment; it requires empathy, patience, and the ability to anticipate the unscripted seconds that matter most. Whether it is the quiet blessing of an elder, the spontaneous laughter between newly married partners, or the electric thrill of unveiling a new vehicle with your family, our mission is to capture feelings, not just poses.
              </p>

              <div className="p-6 rounded-xl bg-[#111111] border border-[#242424] space-y-3">
                <h4 className="text-sm font-semibold text-white">Our Service Promise</h4>
                <ul className="space-y-2 text-xs text-[#BDBDBD]">
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-[#E50914]" />
                    <span>Personalized pre-event consultation directly with Rahul</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-[#E50914]" />
                    <span>Unobtrusive, respectful coverage that lets you enjoy your event</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-[#E50914]" />
                    <span>True-to-life color grading without excessive filters</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-[#E50914]" />
                    <span>Timely digital delivery and handcrafted luxury photobooks</span>
                  </li>
                </ul>
              </div>

              <div className="pt-2 flex flex-wrap items-center gap-4">
                <Link
                  href="/book"
                  className="inline-flex items-center gap-2 px-6 py-3 rounded-full bg-[#E50914] text-white font-semibold text-xs uppercase tracking-wider hover:bg-[#C40812] transition-all"
                >
                  <Calendar className="w-4 h-4" />
                  <span>Check Availability</span>
                </Link>
                <a
                  href={whatsappUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 px-6 py-3 rounded-full bg-[#111111] border border-[#2B2B2B] text-[#25D366] text-xs uppercase tracking-wider font-semibold hover:border-[#25D366] transition-all"
                >
                  <MessageCircle className="w-4 h-4" />
                  <span>Chat on WhatsApp</span>
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Approach Pillars */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-[#090909] border-t border-[#1A1A1A]">
        <div className="max-w-7xl mx-auto">
          <div className="text-center max-w-2xl mx-auto mb-16">
            <h2 className="text-3xl sm:text-4xl font-serif font-normal text-white mb-3">
              The Creative Approach
            </h2>
            <p className="text-sm text-[#8E8E8E]">
              How we approach every project from initial discussion to final delivery.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="p-8 rounded-2xl bg-[#111111] border border-[#222222]">
              <span className="text-3xl font-serif text-[#E50914] font-bold block mb-4">01</span>
              <h3 className="text-lg font-semibold text-white mb-2">Listen &amp; Understand</h3>
              <p className="text-xs text-[#8E8E8E] leading-relaxed">
                We take the time to understand your unique family traditions, event flow, and personal aesthetic preferences to build a tailored coverage plan.
              </p>
            </div>

            <div className="p-8 rounded-2xl bg-[#111111] border border-[#222222]">
              <span className="text-3xl font-serif text-[#E50914] font-bold block mb-4">02</span>
              <h3 className="text-lg font-semibold text-white mb-2">Capture with Emotion</h3>
              <p className="text-xs text-[#8E8E8E] leading-relaxed">
                During your celebration, we blend discrete candid observation with gentle artistic direction so you feel completely natural and relaxed.
              </p>
            </div>

            <div className="p-8 rounded-2xl bg-[#111111] border border-[#222222]">
              <span className="text-3xl font-serif text-[#E50914] font-bold block mb-4">03</span>
              <h3 className="text-lg font-semibold text-white mb-2">Grade &amp; Deliver</h3>
              <p className="text-xs text-[#8E8E8E] leading-relaxed">
                Every frame and video sequence is individually color-graded and retouched to cinematic perfection, delivered through private online cloud galleries.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Pan-India Travel Banner */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 bg-[#050505] border-t border-[#1C1C1C]">
        <div className="max-w-4xl mx-auto text-center p-10 rounded-3xl bg-gradient-to-r from-[#141414] via-[#1A1111] to-[#141414] border border-[#292929]">
          <MapPin className="w-8 h-8 text-[#E50914] mx-auto mb-4" />
          <h3 className="text-2xl sm:text-3xl font-serif text-white mb-3">
            Available Pan-India &amp; Internationally
          </h3>
          <p className="text-sm text-[#BDBDBD] max-w-xl mx-auto mb-6">
            Based in Hyderabad, we frequently travel across Telangana, Andhra Pradesh, Karnataka, Maharashtra, Rajasthan, and across India for destination celebrations.
          </p>
          <Link
            href="/book"
            className="inline-flex items-center gap-2 px-6 py-3 rounded-full bg-[#E50914] text-white text-xs uppercase tracking-wider font-semibold hover:bg-[#C40812] transition-colors"
          >
            <span>Plan Your Destination Event</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </Link>
        </div>
      </section>

      <CtaSection />
      <Footer />
      <WhatsAppFloatingBtn />
    </div>
  );
}
