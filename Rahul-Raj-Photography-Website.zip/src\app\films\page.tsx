"use client";

import { useState } from "react";
import Image from "next/image";
import Link from "next/link";
import { 
  Film, 
  Play, 
  Calendar, 
  Sparkles, 
  MessageCircle, 
  Info,
  Clock
} from "lucide-react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import WhatsAppFloatingBtn from "@/components/WhatsAppFloatingBtn";
import CtaSection from "@/components/CtaSection";
import VideoModal from "@/components/VideoModal";
import { films, FilmItem } from "@/data/films";
import { siteConfig } from "@/data/siteConfig";

export default function FilmsPage() {
  const [selectedFilm, setSelectedFilm] = useState<FilmItem | null>(null);
  const [selectedCategory, setSelectedCategory] = useState<string>("All");

  const categories = [
    "All",
    "Wedding Films",
    "Wedding Highlights",
    "Pre-Wedding Films",
    "Birthday Films",
    "Car Delivery Videos",
  ];

  const filteredFilms = selectedCategory === "All"
    ? films
    : films.filter((f) => f.category === selectedCategory);

  return (
    <div className="min-h-screen bg-[#050505] text-white selection:bg-[#E50914] selection:text-white flex flex-col justify-between">
      <Navbar />

      {/* Header */}
      <section className="relative pt-36 pb-20 px-4 sm:px-6 lg:px-8 border-b border-[#1A1A1A] bg-gradient-to-b from-[#0F0F0F] to-[#050505]">
        <div className="max-w-5xl mx-auto text-center">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-[#161616] border border-[#2B2B2B] text-xs uppercase tracking-widest text-[#BDBDBD] mb-6">
            <Film className="w-3.5 h-3.5 text-[#E50914]" />
            <span>Cinematic Film Production</span>
          </div>
          <h1 className="text-4xl sm:text-6xl font-serif font-normal text-white mb-6">
            Films &amp; Videos Showcase
          </h1>
          <p className="text-base sm:text-lg text-[#BDBDBD] font-light max-w-2xl mx-auto leading-relaxed">
            Experience the motion, music, and raw emotions of our cinematic teasers, wedding films, birthday highlights, and car delivery reels.
          </p>
        </div>
      </section>

      {/* Filter Tabs */}
      <section className="py-8 px-4 sm:px-6 lg:px-8 bg-[#080808] border-b border-[#1A1A1A] sticky top-[72px] z-30 backdrop-blur-md bg-[#080808]/90">
        <div className="max-w-7xl mx-auto overflow-x-auto scrollbar-none flex items-center gap-2.5 py-1">
          {categories.map((cat) => {
            const isActive = selectedCategory === cat;
            return (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`flex-shrink-0 px-4 py-2 rounded-full text-xs font-semibold tracking-wider uppercase transition-all ${
                  isActive
                    ? "bg-[#E50914] text-white shadow-lg shadow-[#E50914]/25"
                    : "bg-[#111111] border border-[#222222] text-[#BDBDBD] hover:text-white hover:border-[#333333]"
                }`}
              >
                {cat}
              </button>
            );
          })}
        </div>
      </section>

      {/* Video Cards Grid */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 bg-[#050505]">
        <div className="max-w-7xl mx-auto">
          {/* Cloud Storage Disclaimer */}
          <div className="mb-10 p-4 rounded-xl bg-[#111111] border border-[#262626] flex items-center gap-3 text-xs text-[#9E9E9E]">
            <Info className="w-5 h-5 text-[#E50914] flex-shrink-0" />
            <p>
              <strong className="text-white">Cloud Video Hosting:</strong> As specified, videos are integrated with high-speed cloud video delivery (Cloudinary streaming). Rahul will be able to upload real 4K video reels directly via the Admin Dashboard.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredFilms.map((film) => (
              <div
                key={film.id}
                className="group relative rounded-2xl overflow-hidden bg-[#111111] border border-[#222222] hover:border-[#E50914]/50 transition-all duration-300 flex flex-col justify-between"
              >
                {/* Video Thumbnail */}
                <div
                  className="relative aspect-video w-full overflow-hidden cursor-pointer"
                  onClick={() => setSelectedFilm(film)}
                >
                  <Image
                    src={film.thumbnail}
                    alt={film.title}
                    fill
                    sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
                    className="object-cover group-hover:scale-105 transition-transform duration-700"
                  />
                  <div className="absolute inset-0 bg-black/40 group-hover:bg-black/20 transition-colors" />

                  {/* Play Button */}
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="w-14 h-14 rounded-full bg-[#E50914] text-white flex items-center justify-center shadow-2xl group-hover:scale-110 transition-transform">
                      <Play className="w-6 h-6 fill-white ml-0.5" />
                    </div>
                  </div>

                  {/* Duration Badge */}
                  <span className="absolute bottom-3 right-3 px-2.5 py-1 rounded-md bg-black/80 backdrop-blur-md text-[11px] font-mono text-white flex items-center gap-1">
                    <Clock className="w-3 h-3" />
                    <span>{film.duration}</span>
                  </span>
                </div>

                {/* Info */}
                <div className="p-6 flex-1 flex flex-col justify-between">
                  <div>
                    <span className="text-[11px] uppercase tracking-wider font-semibold text-[#E50914] block mb-1">
                      {film.category}
                    </span>
                    <h3 className="text-lg font-serif font-medium text-white mb-2 group-hover:text-[#E50914] transition-colors">
                      {film.title}
                    </h3>
                    <p className="text-xs text-[#9E9E9E] line-clamp-2 leading-relaxed mb-5">
                      {film.description}
                    </p>
                  </div>

                  <div className="pt-4 border-t border-[#1C1C1C] flex items-center justify-between">
                    <button
                      onClick={() => setSelectedFilm(film)}
                      className="text-xs uppercase font-semibold text-white hover:text-[#E50914] flex items-center gap-1.5 transition-colors"
                    >
                      <Play className="w-3 h-3 fill-current" />
                      <span>Play Preview</span>
                    </button>

                    <Link
                      href={`/book?service=${encodeURIComponent(film.category)}`}
                      className="text-xs text-[#BDBDBD] hover:text-white"
                    >
                      Enquire Film &rarr;
                    </Link>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Video Modal Player */}
      <VideoModal
        film={selectedFilm}
        onClose={() => setSelectedFilm(null)}
      />

      <CtaSection />
      <Footer />
      <WhatsAppFloatingBtn />
    </div>
  );
}
