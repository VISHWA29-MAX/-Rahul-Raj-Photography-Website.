export interface Category {
  id: string;
  name: string;
  slug: string;
  description: string;
  shortDesc: string;
  coverImage: string;
  featured?: boolean;
}

export const categories: Category[] = [
  {
    id: "weddings",
    name: "Wedding Photography",
    slug: "weddings",
    shortDesc: "Timeless traditional & candid wedding memories captured with emotion and elegance.",
    description: "Complete wedding storytelling capturing grand rituals, sacred moments, emotional tears, and joyful celebrations with artistic flair.",
    coverImage: "https://images.unsplash.com/photo-1519741497674-611481863552?auto=format&fit=crop&w=1200&q=80",
    featured: true,
  },
  {
    id: "full-wedding-packages",
    name: "Full Marriage Packages",
    slug: "full-wedding-packages",
    shortDesc: "End-to-end wedding coverage including photography, videography, drone & luxury albums.",
    description: "Our comprehensive multi-day marriage coverage covering Sangeet, Haldi, Mehendi, Wedding ceremony, and Grand Reception.",
    coverImage: "https://images.unsplash.com/photo-1583939003579-730e3918a45a?auto=format&fit=crop&w=1200&q=80",
    featured: true,
  },
  {
    id: "pre-wedding",
    name: "Pre-Wedding Photography",
    slug: "pre-wedding",
    shortDesc: "Romantic, cinematic couple photoshoots in picturesque outdoor & heritage locations.",
    description: "Intimate and artistic pre-wedding sessions designed around your love story at scenic outdoor destinations or heritage architectural spots.",
    coverImage: "https://images.unsplash.com/photo-1511285560929-80b456fea0bc?auto=format&fit=crop&w=1200&q=80",
    featured: true,
  },
  {
    id: "engagement",
    name: "Engagement",
    slug: "engagement",
    shortDesc: "Cherishing ring exchanges and intimate family celebrations with warmth.",
    description: "Specialized coverage for ring ceremonies, family rituals, and romantic couple portraiture that marks the beginning of your journey.",
    coverImage: "https://images.unsplash.com/photo-1515934751635-c81c6bc9a2d8?auto=format&fit=crop&w=1200&q=80",
    featured: false,
  },
  {
    id: "reception",
    name: "Reception",
    slug: "reception",
    shortDesc: "Glamorous evening celebrations, grand entries, and stage portraits with loved ones.",
    description: "High-energy reception coverage capturing stage aesthetics, grand couple entries, family group photographs, and gala festivities.",
    coverImage: "https://images.unsplash.com/photo-1465495976277-4387d4b0b4c6?auto=format&fit=crop&w=1200&q=80",
    featured: false,
  },
  {
    id: "birthday",
    name: "Birthday Events",
    slug: "birthday",
    shortDesc: "Joyful birthday parties, theme setups, cake-cutting moments, and family portraits.",
    description: "Vibrant coverage for 1st birthdays, milestone jubilees, theme parties, guest interactions, and candid joyful smiles.",
    coverImage: "https://images.unsplash.com/photo-1530103862676-de8c9debad1d?auto=format&fit=crop&w=1200&q=80",
    featured: true,
  },
  {
    id: "car-delivery",
    name: "Car Delivery Photography",
    slug: "car-delivery",
    shortDesc: "Cinematic delivery celebration, showroom unveiling, family joy, and dynamic automobile reels.",
    description: "Commemorate the pride of your new dream car with cinematic showroom unveils, key handover moments, family portraits, and Instagram reels.",
    coverImage: "https://images.unsplash.com/photo-1617814076367-b759c7d7e738?auto=format&fit=crop&w=1200&q=80",
    featured: true,
  },
  {
    id: "maternity",
    name: "Maternity Photography",
    slug: "maternity",
    shortDesc: "Gentle, glowing maternity portraits capturing the beauty of motherly anticipation.",
    description: "Graceful indoor studio or outdoor golden-hour maternity portraits celebrating the beauty, warmth, and miracle of motherhood.",
    coverImage: "https://images.unsplash.com/photo-1555252333-9f8e92e65df9?auto=format&fit=crop&w=1200&q=80",
    featured: false,
  },
  {
    id: "baby",
    name: "Baby Photography",
    slug: "baby",
    shortDesc: "Adorable newborn and toddler photoshoots with safe props and warm lighting.",
    description: "Safe, patient, and heartwarming newborn, infant, and toddler shoots capturing cute expressions and tiny milestone memories.",
    coverImage: "https://images.unsplash.com/photo-1519689680058-324335c77eba?auto=format&fit=crop&w=1200&q=80",
    featured: false,
  },
  {
    id: "family",
    name: "Family Photography",
    slug: "family",
    shortDesc: "Generational family portraits, get-togethers, and candid bonds preserved forever.",
    description: "Warm and candid portraits bringing multiple generations together to preserve genuine love, shared laughter, and heritage.",
    coverImage: "https://images.unsplash.com/photo-1511895426328-dc8714191300?auto=format&fit=crop&w=1200&q=80",
    featured: false,
  },
  {
    id: "corporate",
    name: "Corporate Events",
    slug: "corporate",
    shortDesc: "Professional coverage for conferences, annual galas, award ceremonies & brand launches.",
    description: "Polished corporate event photography for business summits, executive headshots, product unveilings, and gala dinners.",
    coverImage: "https://images.unsplash.com/photo-1511578314322-379afb476865?auto=format&fit=crop&w=1200&q=80",
    featured: false,
  },
  {
    id: "outdoor",
    name: "Outdoor Photography",
    slug: "outdoor",
    shortDesc: "Creative natural-light portraits, fashion shoots, and landscape-framed memories.",
    description: "Vibrant creative photoshoots taking advantage of natural golden light, scenic architecture, and outdoor nature backdrops.",
    coverImage: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=1200&q=80",
    featured: false,
  },
  {
    id: "other-events",
    name: "Other Events",
    slug: "other-events",
    shortDesc: "Custom coverage tailored for housewarmings, anniversaries, and bespoke celebrations.",
    description: "Tailor-made photography and cinematography services for housewarming pujas, milestone anniversaries, and special custom gatherings.",
    coverImage: "https://images.unsplash.com/photo-1464366400600-7168b8af9bc3?auto=format&fit=crop&w=1200&q=80",
    featured: false,
  },
];
