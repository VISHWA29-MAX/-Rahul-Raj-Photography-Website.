"use client";

import { useState, useEffect, Suspense } from "react";
import { useSearchParams } from "next/navigation";
import Link from "next/link";
import { 
  Calendar, 
  Clock, 
  MapPin, 
  Phone, 
  Mail, 
  User, 
  Sparkles, 
  CheckCircle2, 
  AlertCircle, 
  MessageCircle, 
  Info,
  ShieldAlert,
  ArrowRight
} from "lucide-react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import WhatsAppFloatingBtn from "@/components/WhatsAppFloatingBtn";
import { categories } from "@/data/categories";
import { packages } from "@/data/packages";
import { siteConfig } from "@/data/siteConfig";

function BookingFormContent() {
  const searchParams = useSearchParams();
  const preSelectedPackage = searchParams.get("package") || "";
  const preSelectedCategory = searchParams.get("category") || searchParams.get("service") || "";

  // Form State with all 16 Fields
  const [formData, setFormData] = useState({
    fullName: "",
    mobileNumber: "",
    whatsappNumber: "",
    emailAddress: "",
    eventCategory: preSelectedCategory || "Wedding Photography",
    selectedPackage: preSelectedPackage || "",
    eventDate: "",
    eventStartTime: "",
    country: "India",
    state: "",
    city: "",
    eventVenue: "",
    eventAddress: "",
    eventDuration: "",
    estimatedBudget: "",
    additionalRequirements: "",
  });

  const [sameAsMobile, setSameAsMobile] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [bookingReference, setBookingReference] = useState<string | null>(null);

  // Sync WhatsApp number when "Same as Mobile" is checked
  useEffect(() => {
    if (sameAsMobile) {
      setFormData((prev) => ({ ...prev, whatsappNumber: prev.mobileNumber }));
    }
  }, [formData.mobileNumber, sameAsMobile]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    // Generate unique booking reference: RRP-2026-XXXX
    const randomSuffix = Math.floor(1000 + Math.random() * 9000);
    const refNumber = `RRP-2026-${randomSuffix}`;

    // Simulate fast submission & store in state
    setTimeout(() => {
      setBookingReference(refNumber);
      setIsSubmitting(false);
      window.scrollTo({ top: 300, behavior: "smooth" });
    }, 600);
  };

  const whatsappMessage = `Hello Rahul Raj Photography!
I have submitted a booking enquiry on your website.
*Reference Number:* ${bookingReference}
*Name:* ${formData.fullName}
*Event:* ${formData.eventCategory}
*Date:* ${formData.eventDate}
*Location:* ${formData.city}, ${formData.state}
*Package:* ${formData.selectedPackage || "Custom Discussion"}

Please let me know your availability and pricing details.`;

  const whatsappUrl = `https://wa.me/${siteConfig.whatsappNumber}?text=${encodeURIComponent(
    whatsappMessage
  )}`;

  return (
    <div className="max-w-4xl mx-auto">
      {bookingReference ? (
        /* ============================================================== */
        /* SUCCESS CONFIRMATION VIEW                                      */
        /* ============================================================== */
        <div className="p-8 sm:p-12 rounded-3xl bg-[#111111] border border-[#2B2B2B] shadow-2xl text-center space-y-6 animate-fade-in">
          <div className="w-20 h-20 rounded-full bg-[#E50914]/10 border border-[#E50914]/30 flex items-center justify-center text-[#E50914] mx-auto">
            <CheckCircle2 className="w-10 h-10" />
          </div>

          <div className="space-y-2">
            <span className="text-xs uppercase tracking-widest text-[#E50914] font-semibold">
              Enquiry Submitted Successfully
            </span>
            <h2 className="text-2xl sm:text-4xl font-serif text-white">
              Thank You for Choosing Rahul Raj Photography!
            </h2>
            <p className="text-sm text-[#BDBDBD] max-w-lg mx-auto">
              Your booking enquiry has been successfully registered. Our team will contact you shortly to discuss availability and pricing.
            </p>
          </div>

          {/* Reference Card */}
          <div className="p-6 rounded-2xl bg-[#0A0A0A] border border-[#242424] max-w-md mx-auto space-y-2">
            <span className="text-xs text-[#737373] uppercase tracking-wider block">
              Your Enquiry Reference Number
            </span>
            <span className="text-2xl sm:text-3xl font-mono font-bold text-white tracking-widest block text-[#E50914]">
              {bookingReference}
            </span>
            <p className="text-[11px] text-[#8E8E8E]">
              Please save this reference for any future discussions.
            </p>
          </div>

          {/* Summary Box */}
          <div className="p-6 rounded-2xl bg-[#141414] border border-[#222222] max-w-lg mx-auto text-left text-xs space-y-2.5 text-[#BDBDBD]">
            <div className="flex justify-between py-1 border-b border-[#202020]">
              <span className="text-[#737373]">Full Name:</span>
              <span className="font-semibold text-white">{formData.fullName}</span>
            </div>
            <div className="flex justify-between py-1 border-b border-[#202020]">
              <span className="text-[#737373]">Event Category:</span>
              <span className="font-semibold text-white">{formData.eventCategory}</span>
            </div>
            <div className="flex justify-between py-1 border-b border-[#202020]">
              <span className="text-[#737373]">Event Date:</span>
              <span className="font-semibold text-white">{formData.eventDate}</span>
            </div>
            <div className="flex justify-between py-1 border-b border-[#202020]">
              <span className="text-[#737373]">Location:</span>
              <span className="font-semibold text-white">{formData.city}, {formData.state}</span>
            </div>
            {formData.selectedPackage && (
              <div className="flex justify-between py-1">
                <span className="text-[#737373]">Selected Package:</span>
                <span className="font-semibold text-white">{formData.selectedPackage}</span>
              </div>
            )}
          </div>

          {/* Important Rules Banner */}
          <div className="p-4 rounded-xl bg-[#1C1616] border border-[#3E2424] text-xs text-[#E0A8A8] max-w-lg mx-auto flex items-start gap-3 text-left">
            <Info className="w-5 h-5 text-[#E50914] flex-shrink-0 mt-0.5" />
            <p>
              <strong>Important Policy:</strong> Submitting this request does not mean your booking is confirmed. All bookings are manually reviewed by Rahul to avoid double-bookings. Payment is discussed and arranged directly with Rahul.
            </p>
          </div>

          {/* WhatsApp Direct Action */}
          <div className="pt-4 flex flex-col sm:flex-row items-center justify-center gap-4">
            <a
              href={whatsappUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full sm:w-auto inline-flex items-center justify-center gap-2.5 px-8 py-4 rounded-full bg-[#25D366] text-white font-bold text-xs uppercase tracking-wider hover:bg-[#20ba59] transition-all shadow-xl shadow-[#25D366]/20"
            >
              <MessageCircle className="w-4 h-4 fill-white" />
              <span>Continue Discussion on WhatsApp</span>
            </a>

            <Link
              href="/"
              className="w-full sm:w-auto px-6 py-4 rounded-full bg-[#1A1A1A] text-white text-xs uppercase tracking-wider font-semibold hover:bg-[#262626] transition-colors"
            >
              Return to Homepage
            </Link>
          </div>
        </div>
      ) : (
        /* ============================================================== */
        /* BOOKING ENQUIRY FORM (16 FIELDS)                               */
        /* ============================================================== */
        <div className="p-8 sm:p-12 rounded-3xl bg-[#111111] border border-[#262626] shadow-2xl">
          {/* Note Banner */}
          <div className="mb-10 p-4 rounded-xl bg-[#141414] border border-[#2B2B2B] flex items-start gap-3 text-xs text-[#9E9E9E]">
            <ShieldAlert className="w-5 h-5 text-[#E50914] flex-shrink-0 mt-0.5" />
            <div>
              <p className="text-white font-medium mb-0.5">Direct Booking Request</p>
              <p>
                Fill in your event details below. No upfront online payment is charged on this website. Rahul will review your date and discuss packages and pricing directly with you.
              </p>
            </div>
          </div>

          <form onSubmit={handleSubmit} className="space-y-8">
            {/* Step 1: Client Contact Information */}
            <div className="space-y-4">
              <h3 className="text-sm font-semibold uppercase tracking-wider text-[#E50914] pb-2 border-b border-[#1E1E1E]">
                1. Your Contact Details
              </h3>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                {/* 1. Full Name */}
                <div>
                  <label className="block text-xs font-medium text-[#BDBDBD] uppercase tracking-wider mb-2">
                    Full Name <span className="text-[#E50914]">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.fullName}
                    onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                    placeholder="e.g. Vikram Sharma"
                    className="w-full px-4 py-3 rounded-xl bg-[#0D0D0D] border border-[#262626] text-white text-sm focus:border-[#E50914] focus:outline-none transition-colors"
                  />
                </div>

                {/* 4. Email Address */}
                <div>
                  <label className="block text-xs font-medium text-[#BDBDBD] uppercase tracking-wider mb-2">
                    Email Address <span className="text-[#737373]">(Optional)</span>
                  </label>
                  <input
                    type="email"
                    value={formData.emailAddress}
                    onChange={(e) => setFormData({ ...formData, emailAddress: e.target.value })}
                    placeholder="vikram@example.com"
                    className="w-full px-4 py-3 rounded-xl bg-[#0D0D0D] border border-[#262626] text-white text-sm focus:border-[#E50914] focus:outline-none transition-colors"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                {/* 2. Mobile Number */}
                <div>
                  <label className="block text-xs font-medium text-[#BDBDBD] uppercase tracking-wider mb-2">
                    Mobile Number <span className="text-[#E50914]">*</span>
                  </label>
                  <input
                    type="tel"
                    required
                    value={formData.mobileNumber}
                    onChange={(e) => setFormData({ ...formData, mobileNumber: e.target.value })}
                    placeholder="+91 98765 43210"
                    className="w-full px-4 py-3 rounded-xl bg-[#0D0D0D] border border-[#262626] text-white text-sm focus:border-[#E50914] focus:outline-none transition-colors"
                  />
                </div>

                {/* 3. WhatsApp Number */}
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <label className="block text-xs font-medium text-[#BDBDBD] uppercase tracking-wider">
                      WhatsApp Number <span className="text-[#E50914]">*</span>
                    </label>
                    <label className="flex items-center gap-1.5 text-[11px] text-[#8E8E8E] cursor-pointer">
                      <input
                        type="checkbox"
                        checked={sameAsMobile}
                        onChange={(e) => setSameAsMobile(e.target.checked)}
                        className="rounded border-[#333333] text-[#E50914] focus:ring-0"
                      />
                      <span>Same as Mobile</span>
                    </label>
                  </div>
                  <input
                    type="tel"
                    required
                    value={formData.whatsappNumber}
                    onChange={(e) => setFormData({ ...formData, whatsappNumber: e.target.value })}
                    placeholder="+91 98765 43210"
                    disabled={sameAsMobile}
                    className="w-full px-4 py-3 rounded-xl bg-[#0D0D0D] border border-[#262626] text-white text-sm focus:border-[#E50914] focus:outline-none transition-colors disabled:opacity-60"
                  />
                </div>
              </div>
            </div>

            {/* Step 2: Event Details */}
            <div className="space-y-4 pt-4">
              <h3 className="text-sm font-semibold uppercase tracking-wider text-[#E50914] pb-2 border-b border-[#1E1E1E]">
                2. Event &amp; Category Selection
              </h3>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                {/* 5. Event Category */}
                <div>
                  <label className="block text-xs font-medium text-[#BDBDBD] uppercase tracking-wider mb-2">
                    Event Category <span className="text-[#E50914]">*</span>
                  </label>
                  <select
                    required
                    value={formData.eventCategory}
                    onChange={(e) => setFormData({ ...formData, eventCategory: e.target.value })}
                    className="w-full px-4 py-3 rounded-xl bg-[#0D0D0D] border border-[#262626] text-white text-sm focus:border-[#E50914] focus:outline-none transition-colors"
                  >
                    {categories.map((c) => (
                      <option key={c.id} value={c.name}>
                        {c.name}
                      </option>
                    ))}
                  </select>
                </div>

                {/* 6. Select Package */}
                <div>
                  <label className="block text-xs font-medium text-[#BDBDBD] uppercase tracking-wider mb-2">
                    Select Package <span className="text-[#737373]">(Optional)</span>
                  </label>
                  <select
                    value={formData.selectedPackage}
                    onChange={(e) => setFormData({ ...formData, selectedPackage: e.target.value })}
                    className="w-full px-4 py-3 rounded-xl bg-[#0D0D0D] border border-[#262626] text-white text-sm focus:border-[#E50914] focus:outline-none transition-colors"
                  >
                    <option value="">-- Let's discuss suitable package --</option>
                    {packages.map((pkg) => (
                      <option key={pkg.id} value={pkg.name}>
                        {pkg.name} ({pkg.category})
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-5">
                {/* 7. Event Date */}
                <div>
                  <label className="block text-xs font-medium text-[#BDBDBD] uppercase tracking-wider mb-2">
                    Event Date <span className="text-[#E50914]">*</span>
                  </label>
                  <input
                    type="date"
                    required
                    value={formData.eventDate}
                    onChange={(e) => setFormData({ ...formData, eventDate: e.target.value })}
                    className="w-full px-4 py-3 rounded-xl bg-[#0D0D0D] border border-[#262626] text-white text-sm focus:border-[#E50914] focus:outline-none transition-colors"
                  />
                </div>

                {/* 8. Event Start Time */}
                <div>
                  <label className="block text-xs font-medium text-[#BDBDBD] uppercase tracking-wider mb-2">
                    Start Time <span className="text-[#737373]">(Optional)</span>
                  </label>
                  <input
                    type="time"
                    value={formData.eventStartTime}
                    onChange={(e) => setFormData({ ...formData, eventStartTime: e.target.value })}
                    className="w-full px-4 py-3 rounded-xl bg-[#0D0D0D] border border-[#262626] text-white text-sm focus:border-[#E50914] focus:outline-none transition-colors"
                  />
                </div>

                {/* 14. Expected Event Duration */}
                <div>
                  <label className="block text-xs font-medium text-[#BDBDBD] uppercase tracking-wider mb-2">
                    Duration <span className="text-[#737373]">(Optional)</span>
                  </label>
                  <select
                    value={formData.eventDuration}
                    onChange={(e) => setFormData({ ...formData, eventDuration: e.target.value })}
                    className="w-full px-4 py-3 rounded-xl bg-[#0D0D0D] border border-[#262626] text-white text-sm focus:border-[#E50914] focus:outline-none transition-colors"
                  >
                    <option value="">-- Select Duration --</option>
                    <option value="Half Day (3-4 Hours)">Half Day (3-4 Hours)</option>
                    <option value="Full Day (8-10 Hours)">Full Day (8-10 Hours)</option>
                    <option value="2 Days">2 Days (Multi-event)</option>
                    <option value="3+ Days">3+ Days (Complete Wedding)</option>
                  </select>
                </div>
              </div>
            </div>

            {/* Step 3: Location Details */}
            <div className="space-y-4 pt-4">
              <h3 className="text-sm font-semibold uppercase tracking-wider text-[#E50914] pb-2 border-b border-[#1E1E1E]">
                3. Event Location
              </h3>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-5">
                {/* 9. Country */}
                <div>
                  <label className="block text-xs font-medium text-[#BDBDBD] uppercase tracking-wider mb-2">
                    Country <span className="text-[#E50914]">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.country}
                    onChange={(e) => setFormData({ ...formData, country: e.target.value })}
                    className="w-full px-4 py-3 rounded-xl bg-[#0D0D0D] border border-[#262626] text-white text-sm focus:border-[#E50914] focus:outline-none transition-colors"
                  />
                </div>

                {/* 10. State */}
                <div>
                  <label className="block text-xs font-medium text-[#BDBDBD] uppercase tracking-wider mb-2">
                    State <span className="text-[#E50914]">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.state}
                    onChange={(e) => setFormData({ ...formData, state: e.target.value })}
                    placeholder="e.g. Telangana"
                    className="w-full px-4 py-3 rounded-xl bg-[#0D0D0D] border border-[#262626] text-white text-sm focus:border-[#E50914] focus:outline-none transition-colors"
                  />
                </div>

                {/* 11. City */}
                <div>
                  <label className="block text-xs font-medium text-[#BDBDBD] uppercase tracking-wider mb-2">
                    City <span className="text-[#E50914]">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.city}
                    onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                    placeholder="e.g. Hyderabad"
                    className="w-full px-4 py-3 rounded-xl bg-[#0D0D0D] border border-[#262626] text-white text-sm focus:border-[#E50914] focus:outline-none transition-colors"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                {/* 12. Event Venue */}
                <div>
                  <label className="block text-xs font-medium text-[#BDBDBD] uppercase tracking-wider mb-2">
                    Venue Name <span className="text-[#737373]">(Optional)</span>
                  </label>
                  <input
                    type="text"
                    value={formData.eventVenue}
                    onChange={(e) => setFormData({ ...formData, eventVenue: e.target.value })}
                    placeholder="e.g. ITC Kohenur / Dealership Showroom"
                    className="w-full px-4 py-3 rounded-xl bg-[#0D0D0D] border border-[#262626] text-white text-sm focus:border-[#E50914] focus:outline-none transition-colors"
                  />
                </div>

                {/* 13. Event Address */}
                <div>
                  <label className="block text-xs font-medium text-[#BDBDBD] uppercase tracking-wider mb-2">
                    Venue Address <span className="text-[#737373]">(Optional)</span>
                  </label>
                  <input
                    type="text"
                    value={formData.eventAddress}
                    onChange={(e) => setFormData({ ...formData, eventAddress: e.target.value })}
                    placeholder="e.g. Madhapur, Hitec City"
                    className="w-full px-4 py-3 rounded-xl bg-[#0D0D0D] border border-[#262626] text-white text-sm focus:border-[#E50914] focus:outline-none transition-colors"
                  />
                </div>
              </div>
            </div>

            {/* Step 4: Budget & Requirements */}
            <div className="space-y-4 pt-4">
              <h3 className="text-sm font-semibold uppercase tracking-wider text-[#E50914] pb-2 border-b border-[#1E1E1E]">
                4. Custom Requirements &amp; Budget
              </h3>

              {/* 15. Estimated Budget */}
              <div>
                <label className="block text-xs font-medium text-[#BDBDBD] uppercase tracking-wider mb-2">
                  Estimated Budget Preference <span className="text-[#737373]">(Optional)</span>
                </label>
                <select
                  value={formData.estimatedBudget}
                  onChange={(e) => setFormData({ ...formData, estimatedBudget: e.target.value })}
                  className="w-full px-4 py-3 rounded-xl bg-[#0D0D0D] border border-[#262626] text-white text-sm focus:border-[#E50914] focus:outline-none transition-colors"
                >
                  <option value="">-- Flexible / Standard Quote --</option>
                  <option value="Under ₹50,000">Under ₹50,000</option>
                  <option value="₹50,000 – ₹1,00,000">₹50,000 – ₹1,00,000</option>
                  <option value="₹1,00,000 – ₹2,50,000">₹1,00,000 – ₹2,50,000</option>
                  <option value="₹2,50,000+ (Luxury / Multi-Day)">₹2,50,000+ (Luxury / Multi-Day)</option>
                </select>
              </div>

              {/* 16. Additional Requirements */}
              <div>
                <label className="block text-xs font-medium text-[#BDBDBD] uppercase tracking-wider mb-2">
                  Additional Notes or Specific Requests <span className="text-[#737373]">(Optional)</span>
                </label>
                <textarea
                  rows={4}
                  value={formData.additionalRequirements}
                  onChange={(e) => setFormData({ ...formData, additionalRequirements: e.target.value })}
                  placeholder="Tell us about special rituals, drone requirements, album preferences, or specific timings..."
                  className="w-full px-4 py-3 rounded-xl bg-[#0D0D0D] border border-[#262626] text-white text-sm focus:border-[#E50914] focus:outline-none transition-colors"
                />
              </div>
            </div>

            {/* Submission Button */}
            <div className="pt-4">
              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full py-4 rounded-xl bg-[#E50914] text-white font-bold text-xs uppercase tracking-widest hover:bg-[#C40812] transition-all shadow-xl shadow-[#E50914]/25 flex items-center justify-center gap-2 disabled:opacity-50"
              >
                {isSubmitting ? (
                  <span>Registering Enquiry...</span>
                ) : (
                  <>
                    <Calendar className="w-4 h-4" />
                    <span>Submit Booking Enquiry</span>
                  </>
                )}
              </button>
              <p className="text-center text-[11px] text-[#737373] mt-3">
                By submitting this form, you request Rahul Raj Photography to check date availability and share personalized pricing.
              </p>
            </div>
          </form>
        </div>
      )}
    </div>
  );
}

export default function BookPage() {
  return (
    <div className="min-h-screen bg-[#050505] text-white selection:bg-[#E50914] selection:text-white flex flex-col justify-between">
      <Navbar />

      {/* Header */}
      <section className="relative pt-36 pb-16 px-4 sm:px-6 lg:px-8 border-b border-[#1A1A1A] bg-gradient-to-b from-[#0F0F0F] to-[#050505]">
        <div className="max-w-5xl mx-auto text-center">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-[#161616] border border-[#2B2B2B] text-xs uppercase tracking-widest text-[#BDBDBD] mb-6">
            <Calendar className="w-3.5 h-3.5 text-[#E50914]" />
            <span>Event Date Reservation</span>
          </div>
          <h1 className="text-4xl sm:text-6xl font-serif font-normal text-white mb-6">
            Book Your Event
          </h1>
          <p className="text-base sm:text-lg text-[#BDBDBD] font-light max-w-2xl mx-auto leading-relaxed">
            Reserve your wedding, birthday, car delivery, or special celebration. Submissions are reviewed personally by Rahul to ensure dedicated coverage.
          </p>
        </div>
      </section>

      {/* Booking Form Container wrapped in Suspense for search params */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-[#050505]">
        <Suspense fallback={<div className="text-center py-20 text-[#8E8E8E]">Loading booking form...</div>}>
          <BookingFormContent />
        </Suspense>
      </section>

      <Footer />
      <WhatsAppFloatingBtn />
    </div>
  );
}
