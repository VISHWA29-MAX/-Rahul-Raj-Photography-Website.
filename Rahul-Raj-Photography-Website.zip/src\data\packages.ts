export interface PackageItem {
  id: string;
  name: string;
  category: "Weddings" | "Birthdays" | "Car Delivery" | "Other Events";
  categorySlug: string;
  badge?: string;
  shortDesc: string;
  pricingLabel: "CONTACT FOR PRICE";
  inclusions: string[];
  recommended?: boolean;
}

export const packages: PackageItem[] = [
  // A. Full Wedding Packages
  {
    id: "pkg-wedding-traditional",
    name: "Traditional Wedding Photography",
    category: "Weddings",
    categorySlug: "weddings",
    shortDesc: "Essential coverage focusing on ritual authenticity, family portraits, and stage moments.",
    pricingLabel: "CONTACT FOR PRICE",
    inclusions: [
      "Senior traditional photographer coverage",
      "Full coverage of sacred wedding rituals",
      "Stage family and guest portraits",
      "All high-resolution edited digital photographs",
      "Online private gallery delivery",
    ],
  },
  {
    id: "pkg-wedding-candid",
    name: "Candid Wedding Photography",
    category: "Weddings",
    categorySlug: "weddings",
    badge: "Popular",
    shortDesc: "Artistic, unobtrusive photography capturing pure emotional moments and fine details.",
    pricingLabel: "CONTACT FOR PRICE",
    recommended: true,
    inclusions: [
      "Dedicated candid wedding photographer",
      "Creative bride & groom artistic portrait session",
      "Emotional rituals, laughter, and natural guest interactions",
      "Signature Rahul Raj color grading & fine-art retouching",
      "High-res gallery + social-ready highlights",
    ],
  },
  {
    id: "pkg-wedding-photo-video",
    name: "Complete Wedding Photo + Video",
    category: "Weddings",
    categorySlug: "weddings",
    badge: "Best Value",
    shortDesc: "Balanced dual team covering both still photography and traditional videography.",
    pricingLabel: "CONTACT FOR PRICE",
    inclusions: [
      "1 Candid Photographer + 1 Traditional Photographer",
      "1 Traditional Full HD/4K Videographer",
      "Full wedding ceremony documentation",
      "Traditional edited wedding video film",
      "High-resolution edited digital photo collection",
    ],
  },
  {
    id: "pkg-wedding-cinematic",
    name: "Cinematic Wedding Experience",
    category: "Weddings",
    categorySlug: "weddings",
    badge: "Premium",
    shortDesc: "Luxury multi-camera cinema package with drone visuals and cinematic teaser film.",
    pricingLabel: "CONTACT FOR PRICE",
    inclusions: [
      "Multi-camera photo and cinema crew",
      "Cinematic Wedding Film (3-5 min teaser + 15-20 min documentary)",
      "Aerial Drone coverage (subject to venue permission)",
      "Pre-wedding shoot included",
      "Luxury handcrafted hard-bound photobook album",
      "Expedited preview for social media",
    ],
  },
  {
    id: "pkg-wedding-custom",
    name: "Custom Multi-Day Wedding Package",
    category: "Weddings",
    categorySlug: "weddings",
    shortDesc: "Bespoke package tailored specifically for your multi-day itinerary across India or destination weddings.",
    pricingLabel: "CONTACT FOR PRICE",
    inclusions: [
      "Coverage for Mehendi, Haldi, Sangeet, Pellikuthuru, Wedding & Reception",
      "Custom crew sizing adapted to guest volume",
      "Dedicated creative director & lead cinematographers",
      "Custom album design & leatherette presentation box",
      "Flexible travel coverage anywhere in India & internationally",
    ],
  },

  // B. Birthday Packages
  {
    id: "pkg-birthday-photo",
    name: "Birthday Photography Package",
    category: "Birthdays",
    categorySlug: "birthday",
    shortDesc: "Vibrant photo coverage capturing cake cutting, party games, theme decor, and guest portraits.",
    pricingLabel: "CONTACT FOR PRICE",
    inclusions: [
      "Complete coverage of the birthday party",
      "Thematic venue setup and cake decor photos",
      "Cake cutting and guest interaction candid moments",
      "Family & friends group photo sessions",
      "All edited digital photos in high resolution",
    ],
  },
  {
    id: "pkg-birthday-photo-video",
    name: "Birthday Photo + Video Coverage",
    category: "Birthdays",
    categorySlug: "birthday",
    shortDesc: "Complete stills and motion coverage for milestone birthdays and theme parties.",
    pricingLabel: "CONTACT FOR PRICE",
    inclusions: [
      "1 Dedicated Photographer + 1 Videographer",
      "Full event documentation from start to finish",
      "Cake-cutting celebration video",
      "Full HD edited video highlights",
      "Digital photo delivery via cloud link",
    ],
  },
  {
    id: "pkg-birthday-cinematic-reels",
    name: "Cinematic Birthday Film + Reels Package",
    category: "Birthdays",
    categorySlug: "birthday",
    badge: "Trending",
    shortDesc: "Modern cinematic birthday coverage with 4K video highlights and trending vertical reels.",
    pricingLabel: "CONTACT FOR PRICE",
    inclusions: [
      "Artistic photographer + cinematic camera operator",
      "Cinematic 2-3 minute event highlight film",
      "2-3 Curated 9:16 vertical Instagram reels with music",
      "Creative family portrait mini-session",
      "Rapid delivery for quick social media sharing",
    ],
  },

  // C. Car Delivery Packages
  {
    id: "pkg-cardelivery-photo",
    name: "Car Delivery Photography",
    category: "Car Delivery",
    categorySlug: "car-delivery",
    shortDesc: "Capture the proud milestone of taking delivery of your new car at the dealership showroom.",
    pricingLabel: "CONTACT FOR PRICE",
    inclusions: [
      "On-location coverage at the dealership showroom",
      "Car unveiling, ribbon cutting & key handover photos",
      "Family and couple portraits with the vehicle",
      "Creative exterior and interior detail shots",
      "High-res color-graded digital gallery",
    ],
  },
  {
    id: "pkg-cardelivery-cinematic",
    name: "Car Delivery Photo + Cinematic Video",
    category: "Car Delivery",
    categorySlug: "car-delivery",
    badge: "Recommended",
    shortDesc: "High-energy cinematic car delivery coverage with dramatic unveiling reels.",
    pricingLabel: "CONTACT FOR PRICE",
    recommended: true,
    inclusions: [
      "Photographer + Cinematic Videographer at showroom",
      "Dynamic 4K cinematic delivery video film",
      "High-impact 9:16 Instagram reel with cinematic soundtrack",
      "Family celebration & first drive capture",
      "Fast 24-48 hour turnaround",
    ],
  },

  // D. Other Events
  {
    id: "pkg-engagement-reception",
    name: "Engagement & Reception Package",
    category: "Other Events",
    categorySlug: "engagement",
    shortDesc: "Specialized coverage for ring ceremonies, stage entries, and evening receptions.",
    pricingLabel: "CONTACT FOR PRICE",
    inclusions: [
      "Candid & traditional coverage of ceremony",
      "Couple stage portraits and family group sessions",
      "Event highlight video or reels option",
      "Full digital edited gallery",
    ],
  },
  {
    id: "pkg-maternity-baby",
    name: "Maternity & Baby Shoot Package",
    category: "Other Events",
    categorySlug: "maternity",
    shortDesc: "Gentle, comfortable portrait sessions for expecting parents or newborn babies.",
    pricingLabel: "CONTACT FOR PRICE",
    inclusions: [
      "2-3 hour relaxed shoot session (indoor or outdoor)",
      "Multiple outfit changes and gentle posing assistance",
      "Fine-art skin retouching and color enhancement",
      "High-resolution digital delivery",
    ],
  },
  {
    id: "pkg-custom-quote",
    name: "Custom Tailored Event Package",
    category: "Other Events",
    categorySlug: "other-events",
    shortDesc: "Have a corporate summit, housewarming, or custom celebration? Let us build your ideal package.",
    pricingLabel: "CONTACT FOR PRICE",
    inclusions: [
      "Fully customized hours and crew sizing",
      "Tailored mix of photography, videography, or drone",
      "Fast turnaround options for corporate PR",
      "Transparent consultation without hidden charges",
    ],
  },
];
