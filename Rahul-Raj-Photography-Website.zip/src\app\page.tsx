"use client";

import { useState } from "react";
import Image from "next/image";
import Link from "next/link";
import { 
  Camera, 
  Film, 
  Calendar, 
  ArrowRight, 
  Play, 
  Instagram, 
  Sparkles, 
  CheckCircle2, 
  Star, 
  Award, 
  Sliders, 
  Clock, 
  ShieldCheck, 
  HeartHandshake,
  MessageCircle,
  Eye,
  MapPin
} from "lucide-react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import WhatsAppFloatingBtn from "@/components/WhatsAppFloatingBtn";
import CtaSection from "@/components/CtaSection";
import VideoModal from "@/components/VideoModal";
import { categories } from "@/data/categories";
import { portfolioProjects } from "@/data/portfolio";
import { films, FilmItem } from "@/data/films";
import { testimonials } from "@/data/testimonials";
import { siteConfig } from "@/data/siteConfig";

export default function HomePage() {
  const [selectedFilm, setSelectedFilm] = useState<FilmItem | null>(null);

  const whatsappUrl = `https://wa.me/${siteConfig.whatsappNumber}?text=${encodeURIComponent(
    "Hello Rahul Raj Photography, I am browsing your website and would like to enquire about availability for an upcoming event."
  )}`;

  return (
    <div className="min-h-screen bg-[#050505] text-white selection:bg-[#E50914] selection:text-white flex flex-col justify-between">
      <Navbar />

      {/* ============================================================== */}
      {/* SECTION 1: CINEMATIC HERO SECTION                             */}
      {/* ============================================================== */}
      <section className="relative min-h-[92vh] sm:min-h-screen flex items-center justify-center pt-24 pb-16 px-4 sm:px-6 lg:px-8 overflow-hidden">
        {/* Full-width cinematic image background */}
        <div className="absolute inset-0 z-0">
          <Image
            src="https://images.unsplash.com/photo-1519741497674-611481863552?auto=format&fit=crop&w=2000&q=85"
            alt="Rahul Raj Photography Hero"
            fill
            priority
            className="object-cover object-center scale-105 transform animate-fade-in"
          />
          {/* Multi-layer gradient overlays for cinematic mood */}
          <div className="absolute inset-0 bg-gradient-to-t from-[#050505] via-[#050505]/75 to-[#050505]/60" />
          <div className="absolute inset-0 bg-gradient-to-r from-[#050505]/90 via-transparent to-[#050505]/90" />
          <div className="absolute top-1/3 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[300px] bg-[#E50914]/15 blur-[150px] pointer-events-none rounded-full" />
        </div>

        {/* Hero Content */}
        <div className="relative z-10 max-w-5xl mx-auto text-center mt-6">
          <div className="inline-flex items-center gap-2.5 px-4 py-1.5 rounded-full bg-[#111111]/80 backdrop-blur-md border border-[#2B2B2B] text-xs uppercase tracking-widest text-[#BDBDBD] mb-8 shadow-xl">
            <span className="w-2 h-2 rounded-full bg-[#E50914] animate-pulse"></span>
            <span>Premium Wedding, Birthday &amp; Event Cinematography</span>
          </div>

          <h1 className="text-4xl sm:text-6xl md:text-7xl font-serif font-normal tracking-tight text-white mb-6 leading-[1.15]">
            EVERY MOMENT <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-white via-[#F5F5F5] to-[#E50914]">
              DESERVES TO BE REMEMBERED.
            </span>
          </h1>

          <p className="text-base sm:text-xl text-[#D1D1D1] font-light max-w-2xl mx-auto mb-10 leading-relaxed drop-shadow-md">
            Capturing your beautiful moments through professional photography and cinematic storytelling across India and beyond.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <Link
              href="/portfolio"
              className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-8 py-4 rounded-full bg-[#E50914] text-white font-bold text-xs uppercase tracking-widest hover:bg-[#C40812] transition-all shadow-xl shadow-[#E50914]/25 hover:scale-[1.02]"
            >
              <Camera className="w-4 h-4" />
              <span>EXPLORE OUR WORK</span>
            </Link>

            <Link
              href="/book"
              className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-8 py-4 rounded-full bg-[#111111]/90 backdrop-blur-md border border-[#333333] text-white font-semibold text-xs uppercase tracking-widest hover:bg-white hover:text-black transition-all hover:scale-[1.02]"
            >
              <Calendar className="w-4 h-4" />
              <span>BOOK YOUR EVENT</span>
            </Link>
          </div>

          {/* Quick Pillars pill */}
          <div className="mt-14 pt-8 border-t border-white/10 flex flex-wrap items-center justify-center gap-6 text-xs text-[#BDBDBD]">
            <span className="flex items-center gap-1.5">
              <CheckCircle2 className="w-3.5 h-3.5 text-[#E50914]" />
              Weddings &amp; Pre-Weddings
            </span>
            <span className="flex items-center gap-1.5">
              <CheckCircle2 className="w-3.5 h-3.5 text-[#E50914]" />
              Birthdays &amp; Family Jubilees
            </span>
            <span className="flex items-center gap-1.5">
              <CheckCircle2 className="w-3.5 h-3.5 text-[#E50914]" />
              Car Deliveries &amp; Reels
            </span>
            <span className="flex items-center gap-1.5">
              <CheckCircle2 className="w-3.5 h-3.5 text-[#E50914]" />
              Pan-India Coverage
            </span>
          </div>
        </div>
      </section>

      {/* ============================================================== */}
      {/* SECTION 2: INTRODUCTION                                        */}
      {/* ============================================================== */}
      <section className="py-24 px-4 sm:px-6 lg:px-8 bg-[#080808] border-t border-[#191919]">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 items-center">
            {/* Visual Column */}
            <div className="relative group">
              <div className="relative aspect-[4/5] sm:aspect-[4/3] lg:aspect-[4/5] rounded-2xl overflow-hidden border border-[#222222] shadow-2xl">
                <Image
                  src="https://images.unsplash.com/photo-1583939003579-730e3918a45a?auto=format&fit=crop&w=1200&q=80"
                  alt="Storytelling Photography"
                  fill
                  className="object-cover group-hover:scale-105 transition-transform duration-700"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#050505] via-transparent to-transparent opacity-80" />
                
                {/* Overlay Badge */}
                <div className="absolute bottom-6 left-6 right-6 p-4 rounded-xl bg-[#111111]/90 backdrop-blur-md border border-[#262626]">
                  <p className="text-xs uppercase tracking-widest text-[#E50914] font-semibold mb-1">
                    Authentic Moments
                  </p>
                  <p className="text-sm text-white font-medium">
                    Every frame tailored to honor your celebration
                  </p>
                </div>
              </div>

              {/* Decorative accent border */}
              <div className="absolute -bottom-4 -right-4 w-32 h-32 border-b-2 border-r-2 border-[#E50914]/40 rounded-br-2xl pointer-events-none -z-0" />
            </div>

            {/* Narrative Column */}
            <div className="space-y-6">
              <div className="inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-widest text-[#E50914]">
                <Sparkles className="w-4 h-4" />
                <span>Our Philosophy</span>
              </div>

              <h2 className="text-3xl sm:text-4xl md:text-5xl font-serif font-normal text-white leading-tight">
                WE CAPTURE STORIES, <br />
                <span className="text-[#E50914]">NOT JUST PHOTOGRAPHS.</span>
              </h2>

              <p className="text-base sm:text-lg text-[#BDBDBD] font-light leading-relaxed">
                At Rahul Raj Photography, we believe every special moment has a story worth preserving. From beautiful weddings to joyful birthdays and unforgettable celebrations, we capture every emotion through photography and cinematic films.
              </p>

              <p className="text-sm text-[#8E8E8E] leading-relaxed">
                We believe in genuine expressions over rigid posing. Whether it is the quiet glance between a bride and groom during holy vows, the boundless laughter of a child cutting their birthday cake, or the exhilarating pride of taking delivery of your dream automobile — our lenses are always tuned to your real emotion.
              </p>

              <div className="pt-4 flex flex-wrap items-center gap-4">
                <Link
                  href="/about"
                  className="inline-flex items-center gap-2 px-6 py-3 rounded-full bg-[#141414] border border-[#2B2B2B] text-white hover:border-[#E50914] transition-all text-xs uppercase tracking-wider font-semibold"
                >
                  <span>Learn More About Us</span>
                  <ArrowRight className="w-3.5 h-3.5 text-[#E50914]" />
                </Link>
                <a
                  href={whatsappUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 px-6 py-3 rounded-full bg-transparent text-[#25D366] hover:underline text-xs uppercase tracking-wider font-semibold"
                >
                  <MessageCircle className="w-4 h-4" />
                  <span>Talk to Rahul directly</span>
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ============================================================== */}
      {/* SECTION 3: PHOTOGRAPHY SERVICES & CATEGORIES                   */}
      {/* ============================================================== */}
      <section className="py-24 px-4 sm:px-6 lg:px-8 bg-[#050505]">
        <div className="max-w-7xl mx-auto">
          {/* Section Header */}
          <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-6">
            <div>
              <div className="inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-widest text-[#E50914] mb-3">
                <Camera className="w-4 h-4" />
                <span>What We Specialize In</span>
              </div>
              <h2 className="text-3xl sm:text-4xl md:text-5xl font-serif font-normal text-white">
                Photography &amp; Cinematic Services
              </h2>
            </div>
            <p className="text-sm text-[#8E8E8E] max-w-md">
              Specialized coverage tailored for life's most defining milestones. Click any category to explore its dedicated portfolio.
            </p>
          </div>

          {/* Service Cards Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {categories.map((cat) => (
              <div
                key={cat.id}
                className="group relative rounded-2xl overflow-hidden bg-[#111111] border border-[#222222] hover:border-[#E50914]/50 transition-all duration-300 flex flex-col justify-between"
              >
                {/* Image Cover */}
                <div className="relative h-56 w-full overflow-hidden">
                  <Image
                    src={cat.coverImage}
                    alt={cat.name}
                    fill
                    sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 25vw"
                    className="object-cover group-hover:scale-108 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#111111] via-[#111111]/40 to-transparent" />
                  
                  {cat.featured && (
                    <span className="absolute top-3 right-3 px-2.5 py-1 rounded-full bg-[#E50914] text-white text-[10px] uppercase font-bold tracking-wider shadow-md">
                      Featured
                    </span>
                  )}
                </div>

                {/* Card Info */}
                <div className="p-5 flex-1 flex flex-col justify-between">
                  <div>
                    <h3 className="text-lg font-serif font-medium text-white mb-2 group-hover:text-[#E50914] transition-colors">
                      {cat.name}
                    </h3>
                    <p className="text-xs text-[#9E9E9E] line-clamp-2 leading-relaxed mb-4">
                      {cat.shortDesc}
                    </p>
                  </div>

                  <Link
                    href={`/portfolio?category=${cat.slug}`}
                    className="inline-flex items-center gap-1.5 text-xs font-semibold text-white group-hover:text-[#E50914] tracking-wider uppercase pt-2 border-t border-[#1C1C1C] transition-colors"
                  >
                    <span>Explore Gallery</span>
                    <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
                  </Link>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ============================================================== */}
      {/* SECTION 4: FEATURED PORTFOLIO PROJECTS                         */}
      {/* ============================================================== */}
      <section className="py-24 px-4 sm:px-6 lg:px-8 bg-[#090909] border-t border-[#1A1A1A]">
        <div className="max-w-7xl mx-auto">
          {/* Header */}
          <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-6">
            <div>
              <div className="inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-widest text-[#E50914] mb-3">
                <Sparkles className="w-4 h-4" />
                <span>Selected Works</span>
              </div>
              <h2 className="text-3xl sm:text-4xl md:text-5xl font-serif font-normal text-white">
                Featured Photography Projects
              </h2>
            </div>
            <Link
              href="/portfolio"
              className="inline-flex items-center gap-2 text-xs uppercase tracking-wider font-semibold px-5 py-2.5 rounded-full border border-[#2B2B2B] text-white hover:border-[#E50914] hover:text-[#E50914] transition-all"
            >
              <span>View All Portfolio</span>
              <ArrowRight className="w-4 h-4" />
            </Link>
          </div>

          {/* Project Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {portfolioProjects.slice(0, 4).map((project) => (
              <div
                key={project.id}
                className="group relative rounded-2xl overflow-hidden bg-[#121212] border border-[#242424] hover:border-[#E50914]/40 transition-all duration-300"
              >
                <div className="relative aspect-[16/10] overflow-hidden">
                  <Image
                    src={project.coverImage}
                    alt={project.title}
                    fill
                    sizes="(max-width: 768px) 100vw, 50vw"
                    className="object-cover group-hover:scale-105 transition-transform duration-700"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#0D0D0D] via-[#0D0D0D]/40 to-transparent" />
                  
                  {project.isPlaceholder && (
                    <span className="absolute top-4 left-4 px-3 py-1 rounded-full bg-black/60 backdrop-blur-md border border-white/10 text-[10px] text-[#A0A0A0] uppercase tracking-wider">
                      Sample Demonstration Work
                    </span>
                  )}
                  
                  <span className="absolute top-4 right-4 px-3 py-1 rounded-full bg-[#E50914]/90 text-white text-[11px] font-medium tracking-wide">
                    {project.category}
                  </span>
                </div>

                <div className="p-6">
                  <div className="flex items-center gap-2 text-xs text-[#8E8E8E] mb-2">
                    <MapPin className="w-3.5 h-3.5 text-[#E50914]" />
                    <span>{project.location}</span>
                  </div>
                  <h3 className="text-xl font-serif font-medium text-white mb-2 group-hover:text-[#E50914] transition-colors">
                    {project.title}
                  </h3>
                  <p className="text-xs text-[#9E9E9E] line-clamp-2 leading-relaxed mb-5">
                    {project.description}
                  </p>

                  <div className="flex items-center justify-between pt-4 border-t border-[#1F1F1F]">
                    <span className="text-xs text-[#737373]">
                      {project.images.length} High-Res Frames
                    </span>
                    <Link
                      href={`/portfolio?project=${project.slug}`}
                      className="inline-flex items-center gap-1.5 text-xs uppercase font-semibold text-white group-hover:text-[#E50914] tracking-wider transition-colors"
                    >
                      <Eye className="w-3.5 h-3.5" />
                      <span>View Gallery</span>
                    </Link>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ============================================================== */}
      {/* SECTION 5: CINEMATIC FILMS & VIDEOS                            */}
      {/* ============================================================== */}
      <section className="py-24 px-4 sm:px-6 lg:px-8 bg-[#050505] border-t border-[#191919]">
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-6">
            <div>
              <div className="inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-widest text-[#E50914] mb-3">
                <Film className="w-4 h-4" />
                <span>Motion &amp; Sound</span>
              </div>
              <h2 className="text-3xl sm:text-4xl md:text-5xl font-serif font-normal text-white">
                Cinematic Wedding &amp; Event Films
              </h2>
            </div>
            <Link
              href="/films"
              className="inline-flex items-center gap-2 text-xs uppercase tracking-wider font-semibold px-5 py-2.5 rounded-full border border-[#2B2B2B] text-white hover:border-[#E50914] hover:text-[#E50914] transition-all"
            >
              <span>Explore All Films</span>
              <ArrowRight className="w-4 h-4" />
            </Link>
          </div>

          {/* Films Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {films.slice(0, 3).map((film) => (
              <div
                key={film.id}
                className="group relative rounded-2xl overflow-hidden bg-[#111111] border border-[#222222] hover:border-[#E50914]/50 transition-all duration-300 flex flex-col justify-between"
              >
                {/* Video Thumbnail */}
                <div 
                  className="relative aspect-video w-full cursor-pointer overflow-hidden"
                  onClick={() => setSelectedFilm(film)}
                >
                  <Image
                    src={film.thumbnail}
                    alt={film.title}
                    fill
                    sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
                    className="object-cover group-hover:scale-105 transition-transform duration-700"
                  />
                  <div className="absolute inset-0 bg-black/40 group-hover:bg-black/20 transition-colors" />
                  
                  {/* Play Button Icon */}
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="w-14 h-14 rounded-full bg-[#E50914] text-white flex items-center justify-center shadow-2xl group-hover:scale-110 transition-transform">
                      <Play className="w-6 h-6 fill-white ml-0.5" />
                    </div>
                  </div>

                  {/* Duration Tag */}
                  <span className="absolute bottom-3 right-3 px-2.5 py-1 rounded-md bg-black/80 backdrop-blur-md text-[11px] font-mono text-white">
                    {film.duration}
                  </span>
                </div>

                {/* Film Details */}
                <div className="p-5">
                  <span className="text-[11px] uppercase tracking-wider font-semibold text-[#E50914] block mb-1">
                    {film.category}
                  </span>
                  <h3 className="text-base font-medium text-white mb-2 line-clamp-1 group-hover:text-[#E50914] transition-colors">
                    {film.title}
                  </h3>
                  <p className="text-xs text-[#8E8E8E] line-clamp-2 leading-relaxed mb-4">
                    {film.description}
                  </p>

                  <button
                    onClick={() => setSelectedFilm(film)}
                    className="inline-flex items-center gap-1.5 text-xs uppercase font-semibold text-white hover:text-[#E50914] transition-colors"
                  >
                    <span>Watch Preview</span>
                    <Play className="w-3 h-3 fill-current" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ============================================================== */}
      {/* SECTION 6: WHY CHOOSE US                                       */}
      {/* ============================================================== */}
      <section className="py-24 px-4 sm:px-6 lg:px-8 bg-[#080808] border-t border-[#191919]">
        <div className="max-w-7xl mx-auto">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <div className="inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-widest text-[#E50914] mb-3">
              <Award className="w-4 h-4" />
              <span>The Rahul Raj Standard</span>
            </div>
            <h2 className="text-3xl sm:text-4xl md:text-5xl font-serif font-normal text-white mb-4">
              Why Choose Rahul Raj Photography?
            </h2>
            <p className="text-sm sm:text-base text-[#8E8E8E]">
              We approach every event not just as an assignment, but as a priceless chapter in your family history.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="p-6 rounded-2xl bg-[#111111] border border-[#222222] hover:border-[#E50914]/40 transition-colors">
              <div className="w-12 h-12 rounded-xl bg-[#E50914]/10 border border-[#E50914]/20 flex items-center justify-center text-[#E50914] mb-4">
                <Camera className="w-6 h-6" />
              </div>
              <h3 className="text-base font-semibold text-white mb-2">Professional Photography</h3>
              <p className="text-xs text-[#8E8E8E] leading-relaxed">
                Top-of-the-line full-frame camera gear and prime lenses ensuring unmatched clarity and depth in every frame.
              </p>
            </div>

            <div className="p-6 rounded-2xl bg-[#111111] border border-[#222222] hover:border-[#E50914]/40 transition-colors">
              <div className="w-12 h-12 rounded-xl bg-[#E50914]/10 border border-[#E50914]/20 flex items-center justify-center text-[#E50914] mb-4">
                <Sparkles className="w-6 h-6" />
              </div>
              <h3 className="text-base font-semibold text-white mb-2">Creative Storytelling</h3>
              <p className="text-xs text-[#8E8E8E] leading-relaxed">
                Narrative visual direction focusing on real emotions, spontaneous laughter, and unscripted memories.
              </p>
            </div>

            <div className="p-6 rounded-2xl bg-[#111111] border border-[#222222] hover:border-[#E50914]/40 transition-colors">
              <div className="w-12 h-12 rounded-xl bg-[#E50914]/10 border border-[#E50914]/20 flex items-center justify-center text-[#E50914] mb-4">
                <Sliders className="w-6 h-6" />
              </div>
              <h3 className="text-base font-semibold text-white mb-2">Quality Photo Retouching</h3>
              <p className="text-xs text-[#8E8E8E] leading-relaxed">
                Signature color grading and meticulous skin retouching that maintains natural beauty and true tones.
              </p>
            </div>

            <div className="p-6 rounded-2xl bg-[#111111] border border-[#222222] hover:border-[#E50914]/40 transition-colors">
              <div className="w-12 h-12 rounded-xl bg-[#E50914]/10 border border-[#E50914]/20 flex items-center justify-center text-[#E50914] mb-4">
                <Film className="w-6 h-6" />
              </div>
              <h3 className="text-base font-semibold text-white mb-2">Cinematic Video Production</h3>
              <p className="text-xs text-[#8E8E8E] leading-relaxed">
                4K multi-camera cinematography, stabilized gimbal motion, crisp audio recording, and movie-grade grading.
              </p>
            </div>

            <div className="p-6 rounded-2xl bg-[#111111] border border-[#222222] hover:border-[#E50914]/40 transition-colors">
              <div className="w-12 h-12 rounded-xl bg-[#E50914]/10 border border-[#E50914]/20 flex items-center justify-center text-[#E50914] mb-4">
                <ShieldCheck className="w-6 h-6" />
              </div>
              <h3 className="text-base font-semibold text-white mb-2">Attention to Detail</h3>
              <p className="text-xs text-[#8E8E8E] leading-relaxed">
                From intricate jewelry work and venue floral aesthetics to fleeting glances, we miss nothing.
              </p>
            </div>

            <div className="p-6 rounded-2xl bg-[#111111] border border-[#222222] hover:border-[#E50914]/40 transition-colors">
              <div className="w-12 h-12 rounded-xl bg-[#E50914]/10 border border-[#E50914]/20 flex items-center justify-center text-[#E50914] mb-4">
                <HeartHandshake className="w-6 h-6" />
              </div>
              <h3 className="text-base font-semibold text-white mb-2">Personalised Event Coverage</h3>
              <p className="text-xs text-[#8E8E8E] leading-relaxed">
                Tailored shot-lists and pre-event consultations so our coverage aligns seamlessly with your schedule.
              </p>
            </div>

            <div className="p-6 rounded-2xl bg-[#111111] border border-[#222222] hover:border-[#E50914]/40 transition-colors">
              <div className="w-12 h-12 rounded-xl bg-[#E50914]/10 border border-[#E50914]/20 flex items-center justify-center text-[#E50914] mb-4">
                <Clock className="w-6 h-6" />
              </div>
              <h3 className="text-base font-semibold text-white mb-2">Customer-Focused Service</h3>
              <p className="text-xs text-[#8E8E8E] leading-relaxed">
                Prompt communication directly with Rahul, transparent quotes, and dependable on-time delivery.
              </p>
            </div>

            <div className="p-6 rounded-2xl bg-[#111111] border border-[#222222] hover:border-[#E50914]/40 transition-colors">
              <div className="w-12 h-12 rounded-xl bg-[#E50914]/10 border border-[#E50914]/20 flex items-center justify-center text-[#E50914] mb-4">
                <MapPin className="w-6 h-6" />
              </div>
              <h3 className="text-base font-semibold text-white mb-2">Pan-India Availability</h3>
              <p className="text-xs text-[#8E8E8E] leading-relaxed">
                Ready to travel anywhere in India or internationally for destination weddings and signature shoots.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* ============================================================== */}
      {/* SECTION 7: CUSTOMER TESTIMONIALS                               */}
      {/* ============================================================== */}
      <section className="py-24 px-4 sm:px-6 lg:px-8 bg-[#050505] border-t border-[#191919]">
        <div className="max-w-7xl mx-auto">
          <div className="text-center max-w-2xl mx-auto mb-16">
            <div className="inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-widest text-[#E50914] mb-3">
              <Star className="w-4 h-4 fill-[#E50914]" />
              <span>Client Experiences</span>
            </div>
            <h2 className="text-3xl sm:text-4xl md:text-5xl font-serif font-normal text-white mb-3">
              Words From Our Clients
            </h2>
            <p className="text-xs text-[#737373]">
              [Demonstration sample reviews — Can be managed &amp; replaced via the Admin Dashboard]
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {testimonials.map((test) => (
              <div
                key={test.id}
                className="p-6 rounded-2xl bg-[#111111] border border-[#222222] flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center gap-1 text-[#E50914] mb-4">
                    {[...Array(test.rating)].map((_, i) => (
                      <Star key={i} className="w-3.5 h-3.5 fill-current" />
                    ))}
                  </div>
                  <p className="text-xs sm:text-sm text-[#BDBDBD] italic leading-relaxed mb-6 font-light">
                    "{test.reviewText}"
                  </p>
                </div>

                <div className="pt-4 border-t border-[#1C1C1C]">
                  <h4 className="text-sm font-semibold text-white">{test.clientName}</h4>
                  <p className="text-xs text-[#737373]">{test.eventType}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ============================================================== */}
      {/* SECTION 8: INSTAGRAM SHOWCASE                                  */}
      {/* ============================================================== */}
      <section className="py-24 px-4 sm:px-6 lg:px-8 bg-[#080808] border-t border-[#1A1A1A]">
        <div className="max-w-7xl mx-auto text-center">
          <div className="inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-widest text-[#E50914] mb-3">
            <Instagram className="w-4 h-4" />
            <span>Social Connection</span>
          </div>

          <h2 className="text-3xl sm:text-4xl md:text-5xl font-serif font-normal text-white mb-4">
            FOLLOW OUR JOURNEY ON INSTAGRAM
          </h2>

          <p className="text-sm text-[#8E8E8E] max-w-lg mx-auto mb-8">
            Stay tuned with our latest wedding teasers, car delivery reels, behind-the-scenes moments, and fresh photo highlights.
          </p>

          <a
            href={siteConfig.instagramUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2.5 px-6 py-3 rounded-full bg-[#E50914] text-white font-semibold text-xs uppercase tracking-wider hover:bg-[#C40812] transition-all shadow-lg shadow-[#E50914]/20 mb-12"
          >
            <Instagram className="w-4 h-4" />
            <span>{siteConfig.instagramHandle}</span>
          </a>

          {/* Instagram Feed Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
            {[
              "https://images.unsplash.com/photo-1519741497674-611481863552?auto=format&fit=crop&w=600&q=80",
              "https://images.unsplash.com/photo-1511285560929-80b456fea0bc?auto=format&fit=crop&w=600&q=80",
              "https://images.unsplash.com/photo-1617814076367-b759c7d7e738?auto=format&fit=crop&w=600&q=80",
              "https://images.unsplash.com/photo-1530103862676-de8c9debad1d?auto=format&fit=crop&w=600&q=80",
              "https://images.unsplash.com/photo-1583939003579-730e3918a45a?auto=format&fit=crop&w=600&q=80",
              "https://images.unsplash.com/photo-1465495976277-4387d4b0b4c6?auto=format&fit=crop&w=600&q=80",
            ].map((imgUrl, idx) => (
              <a
                key={idx}
                href={siteConfig.instagramUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="group relative aspect-square rounded-xl overflow-hidden border border-[#222222] block"
              >
                <Image
                  src={imgUrl}
                  alt="Instagram post preview"
                  fill
                  sizes="(max-width: 768px) 50vw, (max-width: 1200px) 33vw, 16vw"
                  className="object-cover group-hover:scale-110 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                  <Instagram className="w-6 h-6 text-white" />
                </div>
              </a>
            ))}
          </div>
        </div>
      </section>

      {/* ============================================================== */}
      {/* SECTION 9: FINAL CALL TO ACTION                                */}
      {/* ============================================================== */}
      <CtaSection />

      {/* ============================================================== */}
      {/* SECTION 10: PROFESSIONAL FOOTER                                */}
      {/* ============================================================== */}
      <Footer />

      {/* Interactive Video Modal */}
      <VideoModal
        film={selectedFilm}
        onClose={() => setSelectedFilm(null)}
      />

      {/* Persistent WhatsApp Floating Button */}
      <WhatsAppFloatingBtn />
    </div>
  );
}
