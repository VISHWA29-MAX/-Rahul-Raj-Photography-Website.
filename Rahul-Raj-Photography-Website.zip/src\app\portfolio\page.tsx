"use client";

import { useState, useMemo } from "react";
import Image from "next/image";
import Link from "next/link";
import { 
  Camera, 
  MapPin, 
  Sparkles, 
  Eye, 
  X, 
  ChevronLeft, 
  ChevronRight, 
  Calendar, 
  MessageCircle, 
  Info 
} from "lucide-react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import WhatsAppFloatingBtn from "@/components/WhatsAppFloatingBtn";
import CtaSection from "@/components/CtaSection";
import { portfolioProjects, PortfolioProject } from "@/data/portfolio";
import { categories } from "@/data/categories";
import { siteConfig } from "@/data/siteConfig";

export default function PortfolioPage() {
  const [activeCategory, setActiveCategory] = useState<string>("all");
  const [lightboxProject, setLightboxProject] = useState<PortfolioProject | null>(null);
  const [currentImageIndex, setCurrentImageIndex] = useState<number>(0);

  const categoryFilterList = [
    { slug: "all", name: "All Works" },
    ...categories.map((c) => ({ slug: c.slug, name: c.name })),
  ];

  const filteredProjects = useMemo(() => {
    if (activeCategory === "all") return portfolioProjects;
    return portfolioProjects.filter((p) => p.categorySlug === activeCategory);
  }, [activeCategory]);

  const openLightbox = (project: PortfolioProject, index: number = 0) => {
    setLightboxProject(project);
    setCurrentImageIndex(index);
    document.body.style.overflow = "hidden";
  };

  const closeLightbox = () => {
    setLightboxProject(null);
    setCurrentImageIndex(0);
    document.body.style.overflow = "unset";
  };

  const nextImage = () => {
    if (!lightboxProject) return;
    setCurrentImageIndex((prev) => (prev + 1) % lightboxProject.images.length);
  };

  const prevImage = () => {
    if (!lightboxProject) return;
    setCurrentImageIndex(
      (prev) => (prev - 1 + lightboxProject.images.length) % lightboxProject.images.length
    );
  };

  return (
    <div className="min-h-screen bg-[#050505] text-white selection:bg-[#E50914] selection:text-white flex flex-col justify-between">
      <Navbar />

      {/* Header */}
      <section className="relative pt-36 pb-20 px-4 sm:px-6 lg:px-8 border-b border-[#1A1A1A] bg-gradient-to-b from-[#0F0F0F] to-[#050505]">
        <div className="max-w-5xl mx-auto text-center">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-[#161616] border border-[#2B2B2B] text-xs uppercase tracking-widest text-[#BDBDBD] mb-6">
            <Camera className="w-3.5 h-3.5 text-[#E50914]" />
            <span>Visual Gallery &amp; Stories</span>
          </div>
          <h1 className="text-4xl sm:text-6xl font-serif font-normal text-white mb-6">
            Our Photography Portfolio
          </h1>
          <p className="text-base sm:text-lg text-[#BDBDBD] font-light max-w-2xl mx-auto leading-relaxed">
            Explore our curated projects capturing sacred ceremonies, joyous milestones, candid emotional portraits, and dynamic car delivery stories.
          </p>
        </div>
      </section>

      {/* Category Tabs */}
      <section className="py-8 px-4 sm:px-6 lg:px-8 bg-[#080808] border-b border-[#1A1A1A] sticky top-[72px] z-30 backdrop-blur-md bg-[#080808]/90">
        <div className="max-w-7xl mx-auto overflow-x-auto scrollbar-none flex items-center gap-2 py-1">
          {categoryFilterList.map((cat) => {
            const isActive = activeCategory === cat.slug;
            return (
              <button
                key={cat.slug}
                onClick={() => setActiveCategory(cat.slug)}
                className={`flex-shrink-0 px-4 py-2 rounded-full text-xs font-semibold tracking-wider uppercase transition-all ${
                  isActive
                    ? "bg-[#E50914] text-white shadow-lg shadow-[#E50914]/25"
                    : "bg-[#111111] border border-[#222222] text-[#BDBDBD] hover:text-white hover:border-[#333333]"
                }`}
              >
                {cat.name}
              </button>
            );
          })}
        </div>
      </section>

      {/* Gallery Grid */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 bg-[#050505]">
        <div className="max-w-7xl mx-auto">
          {/* Demonstration Placeholder Disclaimer */}
          <div className="mb-10 p-4 rounded-xl bg-[#111111] border border-[#262626] flex items-center gap-3 text-xs text-[#9E9E9E]">
            <Info className="w-5 h-5 text-[#E50914] flex-shrink-0" />
            <p>
              <strong className="text-white">Demonstration Gallery:</strong> Displaying high-resolution professional photography placeholders. Rahul can upload real client projects, galleries, and videos seamlessly via the upcoming Admin Dashboard.
            </p>
          </div>

          {filteredProjects.length === 0 ? (
            <div className="text-center py-20 p-8 rounded-2xl bg-[#0D0D0D] border border-[#1E1E1E]">
              <Camera className="w-10 h-10 text-[#737373] mx-auto mb-3" />
              <h3 className="text-lg font-serif text-white mb-2">No Projects In This Category Yet</h3>
              <p className="text-xs text-[#8E8E8E] max-w-md mx-auto mb-6">
                Photographs and galleries for this category will be uploaded through the admin management console.
              </p>
              <button
                onClick={() => setActiveCategory("all")}
                className="px-5 py-2.5 rounded-full bg-[#E50914] text-white text-xs font-semibold uppercase tracking-wider"
              >
                View All Categories
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {filteredProjects.map((project) => (
                <div
                  key={project.id}
                  className="group relative rounded-2xl overflow-hidden bg-[#111111] border border-[#222222] hover:border-[#E50914]/40 transition-all duration-300 flex flex-col justify-between"
                >
                  {/* Cover Image Container */}
                  <div
                    className="relative aspect-[4/3] w-full overflow-hidden cursor-pointer"
                    onClick={() => openLightbox(project, 0)}
                  >
                    <Image
                      src={project.coverImage}
                      alt={project.title}
                      fill
                      sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
                      className="object-cover group-hover:scale-105 transition-transform duration-700"
                    />
                    <div className="absolute inset-0 bg-black/30 group-hover:bg-black/10 transition-colors" />

                    {/* Quick Preview Badge */}
                    <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                      <span className="px-4 py-2 rounded-full bg-black/75 backdrop-blur-md border border-white/20 text-xs font-semibold text-white flex items-center gap-2">
                        <Eye className="w-4 h-4 text-[#E50914]" />
                        <span>View Gallery ({project.images.length})</span>
                      </span>
                    </div>

                    <span className="absolute top-3 right-3 px-2.5 py-1 rounded-full bg-[#E50914] text-white text-[10px] font-medium tracking-wide">
                      {project.category}
                    </span>
                  </div>

                  {/* Information */}
                  <div className="p-6 flex-1 flex flex-col justify-between">
                    <div>
                      <div className="flex items-center gap-1.5 text-xs text-[#8E8E8E] mb-2">
                        <MapPin className="w-3.5 h-3.5 text-[#E50914]" />
                        <span>{project.location}</span>
                      </div>
                      <h3 className="text-lg font-serif font-medium text-white mb-2 group-hover:text-[#E50914] transition-colors">
                        {project.title}
                      </h3>
                      <p className="text-xs text-[#9E9E9E] line-clamp-2 leading-relaxed mb-4">
                        {project.description}
                      </p>
                    </div>

                    <div className="pt-4 border-t border-[#1C1C1C] flex items-center justify-between">
                      <button
                        onClick={() => openLightbox(project, 0)}
                        className="text-xs text-[#E50914] font-semibold hover:underline flex items-center gap-1"
                      >
                        <span>Open Lightbox</span>
                        <span>&rarr;</span>
                      </button>

                      <Link
                        href={`/book?project=${encodeURIComponent(project.title)}`}
                        className="text-xs text-[#BDBDBD] hover:text-white"
                      >
                        Enquire similar &rarr;
                      </Link>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* Lightbox Modal */}
      {lightboxProject && (
        <div 
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/95 backdrop-blur-md p-4 sm:p-6"
          onClick={closeLightbox}
        >
          {/* Close Button */}
          <button
            onClick={closeLightbox}
            className="absolute top-6 right-6 z-50 p-3 rounded-full bg-[#1A1A1A] text-white hover:bg-[#E50914] transition-colors"
            aria-label="Close Lightbox"
          >
            <X className="w-6 h-6" />
          </button>

          {/* Previous Button */}
          <button
            onClick={(e) => {
              e.stopPropagation();
              prevImage();
            }}
            className="absolute left-4 sm:left-8 top-1/2 -translate-y-1/2 z-50 p-3 rounded-full bg-black/60 hover:bg-[#E50914] text-white border border-white/10 transition-colors"
            aria-label="Previous Image"
          >
            <ChevronLeft className="w-6 h-6" />
          </button>

          {/* Next Button */}
          <button
            onClick={(e) => {
              e.stopPropagation();
              nextImage();
            }}
            className="absolute right-4 sm:right-8 top-1/2 -translate-y-1/2 z-50 p-3 rounded-full bg-black/60 hover:bg-[#E50914] text-white border border-white/10 transition-colors"
            aria-label="Next Image"
          >
            <ChevronRight className="w-6 h-6" />
          </button>

          {/* Lightbox Content Container */}
          <div
            className="relative max-w-5xl w-full max-h-[85vh] flex flex-col items-center justify-center"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Main Active Photograph */}
            <div className="relative w-full h-[65vh] rounded-xl overflow-hidden shadow-2xl">
              <Image
                src={lightboxProject.images[currentImageIndex]}
                alt={`${lightboxProject.title} image ${currentImageIndex + 1}`}
                fill
                priority
                className="object-contain"
              />
            </div>

            {/* Lightbox Caption & Thumbnails */}
            <div className="mt-4 w-full bg-[#111111]/90 backdrop-blur border border-[#242424] p-4 rounded-xl flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-[#BDBDBD]">
              <div>
                <h4 className="text-white font-serif text-sm font-medium">
                  {lightboxProject.title}
                </h4>
                <p className="text-[#8E8E8E]">
                  {lightboxProject.category} • {lightboxProject.location} • Frame {currentImageIndex + 1} of {lightboxProject.images.length}
                </p>
              </div>

              <div className="flex items-center gap-3">
                <Link
                  href={`/book?category=${lightboxProject.categorySlug}`}
                  className="px-4 py-2 rounded-lg bg-[#E50914] text-white font-semibold uppercase tracking-wider text-[11px]"
                >
                  Book Event Like This
                </Link>
              </div>
            </div>
          </div>
        </div>
      )}

      <CtaSection />
      <Footer />
      <WhatsAppFloatingBtn />
    </div>
  );
}
