import type { Metadata } from "next";
import { Inter, Playfair_Display } from "next/font/google";
import "./globals.css";

const inter = Inter({
  subsets: ["latin"],
  variable: "--font-inter",
  display: "swap",
});

const playfair = Playfair_Display({
  subsets: ["latin"],
  variable: "--font-playfair",
  display: "swap",
});

export const metadata: Metadata = {
  title: "Rahul Raj Photography | Wedding, Birthday & Event Photography",
  description: "Explore professional wedding photography, birthday photography, car delivery shoots, pre-wedding photography and cinematic films by Rahul Raj Photography.",
  icons: {
    icon: "/logo/logo-dark-bg.png",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className={`${inter.variable} ${playfair.variable}`}>
      <body className="bg-brand-dark text-brand-textPrimary antialiased selection:bg-brand-red selection:text-white">
        {children}
      </body>
    </html>
  );
}
