"use client";

import { MessageCircle } from "lucide-react";
import { siteConfig } from "@/data/siteConfig";

export default function WhatsAppFloatingBtn() {
  const whatsappUrl = `https://wa.me/${siteConfig.whatsappNumber}?text=${encodeURIComponent(
    "Hello Rahul Raj Photography! I am interested in booking your photography/cinematography services. Please let me know your availability."
  )}`;

  return (
    <aside aria-label="WhatsApp enquiry shortcut" className="fixed bottom-6 right-6 z-40 group">
      <a
        href={whatsappUrl}
        target="_blank"
        rel="noopener noreferrer"
        aria-label="Enquire directly on WhatsApp"
        className="flex items-center gap-3 px-4 py-3 rounded-full bg-[#25D366] text-white shadow-2xl hover:bg-[#20ba59] transition-all transform hover:scale-105"
      >
        <MessageCircle className="w-6 h-6 fill-white" />
        <span className="hidden sm:inline font-semibold text-xs tracking-wider uppercase">
          Enquire on WhatsApp
        </span>
      </a>
    </aside>
  );
}
