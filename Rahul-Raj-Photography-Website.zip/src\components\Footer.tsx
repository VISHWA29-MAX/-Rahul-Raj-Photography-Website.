import Link from "next/link";
import Image from "next/image";
import { 
  Instagram, 
  MessageCircle, 
  Phone, 
  Mail, 
  MapPin, 
  ArrowUpRight,
  Heart
} from "lucide-react";
import { siteConfig } from "@/data/siteConfig";
import { categories } from "@/data/categories";

export default function Footer() {
  const whatsappUrl = `https://wa.me/${siteConfig.whatsappNumber}?text=${encodeURIComponent(
    "Hello Rahul Raj Photography, I would like to inquire about event photography packages."
  )}`;

  return (
    <footer className="bg-[#050505] text-[#BDBDBD] border-t border-[#1C1C1C] relative z-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-16 pb-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10 mb-14">
          {/* Brand Info */}
          <div className="lg:col-span-2 space-y-5">
            <Link href="/" className="inline-block">
              <div className="relative h-12 w-52 sm:w-60">
                <Image
                  src="/logo/logo.svg"
                  alt="Rahul Raj Photography"
                  fill
                  className="object-contain object-left"
                />
              </div>
            </Link>
            <p className="text-sm text-[#9E9E9E] leading-relaxed max-w-sm">
              Capturing life's most precious celebrations through high-definition photography and cinematic storytelling. From intimate rituals to grand spectacles, every moment deserves to be remembered.
            </p>
            <div className="flex items-center gap-3 pt-2">
              <a
                href={siteConfig.instagramUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 rounded-full bg-[#121212] border border-[#262626] flex items-center justify-center text-white hover:border-[#E50914] hover:text-[#E50914] transition-all"
                aria-label="Instagram"
              >
                <Instagram className="w-4 h-4" />
              </a>
              <a
                href={whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 rounded-full bg-[#121212] border border-[#262626] flex items-center justify-center text-white hover:border-[#25D366] hover:text-[#25D366] transition-all"
                aria-label="WhatsApp"
              >
                <MessageCircle className="w-4 h-4" />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div className="space-y-4">
            <h4 className="text-sm font-semibold tracking-wider text-white uppercase font-sans">
              Navigation
            </h4>
            <ul className="space-y-2.5 text-sm">
              <li>
                <Link href="/" className="hover:text-white transition-colors">
                  Home
                </Link>
              </li>
              <li>
                <Link href="/about" className="hover:text-white transition-colors">
                  About Us
                </Link>
              </li>
              <li>
                <Link href="/portfolio" className="hover:text-white transition-colors">
                  Portfolio Gallery
                </Link>
              </li>
              <li>
                <Link href="/services" className="hover:text-white transition-colors">
                  Services
                </Link>
              </li>
              <li>
                <Link href="/packages" className="hover:text-white transition-colors">
                  Packages &amp; Pricing
                </Link>
              </li>
              <li>
                <Link href="/films" className="hover:text-white transition-colors">
                  Films &amp; Videos
                </Link>
              </li>
              <li>
                <Link href="/book" className="hover:text-white transition-colors text-[#E50914] font-medium">
                  Book Your Event
                </Link>
              </li>
            </ul>
          </div>

          {/* Photography Categories */}
          <div className="space-y-4">
            <h4 className="text-sm font-semibold tracking-wider text-white uppercase font-sans">
              Services
            </h4>
            <ul className="space-y-2.5 text-sm">
              {categories.slice(0, 6).map((cat) => (
                <li key={cat.id}>
                  <Link
                    href={`/portfolio?category=${cat.slug}`}
                    className="hover:text-white transition-colors flex items-center gap-1 group"
                  >
                    <span>{cat.name}</span>
                    <ArrowUpRight className="w-3 h-3 opacity-0 -translate-y-0.5 group-hover:opacity-100 transition-opacity" />
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact Details (Editable Placeholders) */}
          <div className="space-y-4">
            <h4 className="text-sm font-semibold tracking-wider text-white uppercase font-sans">
              Get in Touch
            </h4>
            <div className="space-y-3 text-sm text-[#9E9E9E]">
              <div className="flex items-start gap-3">
                <MapPin className="w-4 h-4 text-[#E50914] flex-shrink-0 mt-0.5" />
                <span>{siteConfig.serviceArea}</span>
              </div>
              <div className="flex items-center gap-3">
                <Phone className="w-4 h-4 text-[#E50914] flex-shrink-0" />
                <a href={`tel:${siteConfig.phone}`} className="hover:text-white transition-colors">
                  {siteConfig.phone}
                </a>
              </div>
              <div className="flex items-center gap-3">
                <Mail className="w-4 h-4 text-[#E50914] flex-shrink-0" />
                <a href={`mailto:${siteConfig.email}`} className="hover:text-white transition-colors">
                  {siteConfig.email}
                </a>
              </div>
              <div className="pt-2">
                <a
                  href={siteConfig.instagramUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-xs text-[#E50914] hover:underline flex items-center gap-1"
                >
                  <span>{siteConfig.instagramHandle}</span>
                  <ArrowUpRight className="w-3 h-3" />
                </a>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-[#1A1A1A] pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-[#737373]">
          <p>
            © {new Date().getFullYear()} {siteConfig.name}. All rights reserved.
          </p>
          <p className="flex items-center gap-1.5">
            <span>Crafted with</span>
            <Heart className="w-3.5 h-3.5 text-[#E50914] fill-[#E50914]" />
            <span>for timeless celebrations across India &amp; Worldwide.</span>
          </p>
        </div>
      </div>
    </footer>
  );
}
