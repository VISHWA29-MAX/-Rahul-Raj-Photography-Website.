"use client";

import { useState } from "react";
import Link from "next/link";
import { 
  MapPin, 
  Phone, 
  Mail, 
  Instagram, 
  MessageCircle, 
  Clock, 
  Send, 
  CheckCircle2, 
  Sparkles 
} from "lucide-react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import WhatsAppFloatingBtn from "@/components/WhatsAppFloatingBtn";
import { siteConfig } from "@/data/siteConfig";

export default function ContactPage() {
  const [formData, setFormData] = useState({
    name: "",
    phone: "",
    email: "",
    eventType: "Wedding",
    message: "",
  });
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
  };

  const whatsappUrl = `https://wa.me/${siteConfig.whatsappNumber}?text=${encodeURIComponent(
    `Hello Rahul, my name is ${formData.name || "Customer"}. I am interested in photography services for a ${formData.eventType}. Please let me know your availability.`
  )}`;

  return (
    <div className="min-h-screen bg-[#050505] text-white selection:bg-[#E50914] selection:text-white flex flex-col justify-between">
      <Navbar />

      {/* Header */}
      <section className="relative pt-36 pb-20 px-4 sm:px-6 lg:px-8 border-b border-[#1A1A1A] bg-gradient-to-b from-[#0F0F0F] to-[#050505]">
        <div className="max-w-5xl mx-auto text-center">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-[#161616] border border-[#2B2B2B] text-xs uppercase tracking-widest text-[#BDBDBD] mb-6">
            <MessageCircle className="w-3.5 h-3.5 text-[#E50914]" />
            <span>Connect Directly</span>
          </div>
          <h1 className="text-4xl sm:text-6xl font-serif font-normal text-white mb-6">
            Get In Touch With Rahul
          </h1>
          <p className="text-base sm:text-lg text-[#BDBDBD] font-light max-w-2xl mx-auto leading-relaxed">
            Have questions about dates, bespoke event coverage, or album design? Send us a message or chat with Rahul directly on WhatsApp.
          </p>
        </div>
      </section>

      {/* Contact Grid */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-[#050505]">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
            {/* Contact Details Column */}
            <div className="lg:col-span-5 space-y-8">
              <div>
                <h2 className="text-2xl font-serif font-medium text-white mb-3">
                  Direct Contact Information
                </h2>
                <p className="text-sm text-[#9E9E9E] leading-relaxed">
                  We respond promptly to all booking enquiries and consultation calls.
                </p>
              </div>

              <div className="space-y-4">
                {/* WhatsApp Priority Card */}
                <a
                  href={whatsappUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="p-5 rounded-2xl bg-[#111111] border border-[#262626] hover:border-[#25D366] transition-all flex items-start gap-4 group"
                >
                  <div className="w-12 h-12 rounded-xl bg-[#25D366]/10 flex items-center justify-center text-[#25D366] flex-shrink-0">
                    <MessageCircle className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="text-sm font-semibold text-white group-hover:text-[#25D366] transition-colors">
                      WhatsApp Quick Chat (Recommended)
                    </h3>
                    <p className="text-xs text-[#8E8E8E] mb-2">
                      Instant replies, portfolio sharing &amp; direct discussion with Rahul.
                    </p>
                    <span className="text-xs font-semibold text-[#25D366]">
                      Click to Open WhatsApp &rarr;
                    </span>
                  </div>
                </a>

                {/* Phone */}
                <div className="p-5 rounded-2xl bg-[#111111] border border-[#262626] flex items-start gap-4">
                  <div className="w-12 h-12 rounded-xl bg-[#E50914]/10 flex items-center justify-center text-[#E50914] flex-shrink-0">
                    <Phone className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="text-sm font-semibold text-white">Call Us</h3>
                    <p className="text-xs text-[#8E8E8E] mb-1">Available 10:00 AM – 8:00 PM</p>
                    <a href={`tel:${siteConfig.phone}`} className="text-xs text-white hover:text-[#E50914] font-medium">
                      {siteConfig.phone}
                    </a>
                  </div>
                </div>

                {/* Email */}
                <div className="p-5 rounded-2xl bg-[#111111] border border-[#262626] flex items-start gap-4">
                  <div className="w-12 h-12 rounded-xl bg-[#E50914]/10 flex items-center justify-center text-[#E50914] flex-shrink-0">
                    <Mail className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="text-sm font-semibold text-white">Email Enquiries</h3>
                    <p className="text-xs text-[#8E8E8E] mb-1">For event itineraries and corporate proposals</p>
                    <a href={`mailto:${siteConfig.email}`} className="text-xs text-white hover:text-[#E50914] font-medium">
                      {siteConfig.email}
                    </a>
                  </div>
                </div>

                {/* Location */}
                <div className="p-5 rounded-2xl bg-[#111111] border border-[#262626] flex items-start gap-4">
                  <div className="w-12 h-12 rounded-xl bg-[#E50914]/10 flex items-center justify-center text-[#E50914] flex-shrink-0">
                    <MapPin className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="text-sm font-semibold text-white">Studio Base &amp; Travel</h3>
                    <p className="text-xs text-[#BDBDBD] font-medium mb-1">{siteConfig.address}</p>
                    <p className="text-xs text-[#8E8E8E]">{siteConfig.serviceArea}</p>
                  </div>
                </div>

                {/* Instagram */}
                <a
                  href={siteConfig.instagramUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="p-5 rounded-2xl bg-[#111111] border border-[#262626] hover:border-[#E50914] transition-all flex items-start gap-4 group"
                >
                  <div className="w-12 h-12 rounded-xl bg-[#E50914]/10 flex items-center justify-center text-[#E50914] flex-shrink-0">
                    <Instagram className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="text-sm font-semibold text-white group-hover:text-[#E50914] transition-colors">
                      Instagram Profile
                    </h3>
                    <p className="text-xs text-[#8E8E8E] mb-1">
                      See daily stories, behind-the-scenes, and recent wedding reels.
                    </p>
                    <span className="text-xs font-semibold text-[#E50914]">
                      {siteConfig.instagramHandle} &rarr;
                    </span>
                  </div>
                </a>
              </div>
            </div>

            {/* Quick Contact Form Column */}
            <div className="lg:col-span-7">
              <div className="p-8 sm:p-10 rounded-3xl bg-[#111111] border border-[#262626] shadow-2xl">
                <div className="mb-8">
                  <h2 className="text-2xl font-serif font-medium text-white mb-2">
                    Send an Enquiry Message
                  </h2>
                  <p className="text-xs text-[#8E8E8E]">
                    Fill in your event details below and we will get back to you with pricing options.
                  </p>
                </div>

                {submitted ? (
                  <div className="p-8 rounded-2xl bg-[#161616] border border-[#2B2B2B] text-center space-y-4">
                    <div className="w-14 h-14 rounded-full bg-[#E50914]/10 border border-[#E50914]/30 flex items-center justify-center text-[#E50914] mx-auto">
                      <CheckCircle2 className="w-8 h-8" />
                    </div>
                    <h3 className="text-xl font-serif text-white">Thank You, {formData.name}!</h3>
                    <p className="text-xs text-[#BDBDBD] max-w-md mx-auto leading-relaxed">
                      Your enquiry has been received. Rahul will reach out to you directly to discuss dates and custom pricing.
                    </p>
                    <div className="pt-4 flex flex-col sm:flex-row items-center justify-center gap-3">
                      <a
                        href={whatsappUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="px-6 py-2.5 rounded-full bg-[#25D366] text-white text-xs font-semibold flex items-center gap-2"
                      >
                        <MessageCircle className="w-4 h-4" />
                        <span>Continue to WhatsApp</span>
                      </a>
                      <button
                        onClick={() => setSubmitted(false)}
                        className="px-5 py-2.5 rounded-full bg-[#222222] text-xs text-white"
                      >
                        Send Another Note
                      </button>
                    </div>
                  </div>
                ) : (
                  <form onSubmit={handleSubmit} className="space-y-5">
                    <div>
                      <label className="block text-xs font-medium text-[#BDBDBD] uppercase tracking-wider mb-2">
                        Your Full Name *
                      </label>
                      <input
                        type="text"
                        required
                        value={formData.name}
                        onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                        placeholder="e.g. Vikram Sharma"
                        className="w-full px-4 py-3 rounded-xl bg-[#0D0D0D] border border-[#262626] text-white text-sm focus:border-[#E50914] focus:outline-none transition-colors"
                      />
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-xs font-medium text-[#BDBDBD] uppercase tracking-wider mb-2">
                          Mobile / WhatsApp Number *
                        </label>
                        <input
                          type="tel"
                          required
                          value={formData.phone}
                          onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                          placeholder="+91 98765 43210"
                          className="w-full px-4 py-3 rounded-xl bg-[#0D0D0D] border border-[#262626] text-white text-sm focus:border-[#E50914] focus:outline-none transition-colors"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-medium text-[#BDBDBD] uppercase tracking-wider mb-2">
                          Email Address (Optional)
                        </label>
                        <input
                          type="email"
                          value={formData.email}
                          onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                          placeholder="vikram@example.com"
                          className="w-full px-4 py-3 rounded-xl bg-[#0D0D0D] border border-[#262626] text-white text-sm focus:border-[#E50914] focus:outline-none transition-colors"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-xs font-medium text-[#BDBDBD] uppercase tracking-wider mb-2">
                        Event Category
                      </label>
                      <select
                        value={formData.eventType}
                        onChange={(e) => setFormData({ ...formData, eventType: e.target.value })}
                        className="w-full px-4 py-3 rounded-xl bg-[#0D0D0D] border border-[#262626] text-white text-sm focus:border-[#E50914] focus:outline-none transition-colors"
                      >
                        <option value="Wedding Photography">Wedding Photography</option>
                        <option value="Full Marriage Packages">Full Marriage Packages</option>
                        <option value="Pre-Wedding Shoot">Pre-Wedding Shoot</option>
                        <option value="Birthday Event">Birthday Event</option>
                        <option value="Car Delivery Shoot">Car Delivery Shoot</option>
                        <option value="Engagement / Reception">Engagement / Reception</option>
                        <option value="Maternity / Baby Shoot">Maternity / Baby Shoot</option>
                        <option value="Corporate / Other Event">Corporate / Other Event</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-xs font-medium text-[#BDBDBD] uppercase tracking-wider mb-2">
                        Event Details &amp; Location *
                      </label>
                      <textarea
                        required
                        rows={4}
                        value={formData.message}
                        onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                        placeholder="Tell us about the event date, venue location, and requirements..."
                        className="w-full px-4 py-3 rounded-xl bg-[#0D0D0D] border border-[#262626] text-white text-sm focus:border-[#E50914] focus:outline-none transition-colors"
                      />
                    </div>

                    <div className="pt-2">
                      <button
                        type="submit"
                        className="w-full py-4 rounded-xl bg-[#E50914] text-white font-bold text-xs uppercase tracking-wider hover:bg-[#C40812] transition-colors flex items-center justify-center gap-2 shadow-xl shadow-[#E50914]/25"
                      >
                        <Send className="w-4 h-4" />
                        <span>Submit Enquiry</span>
                      </button>
                    </div>
                  </form>
                )}
              </div>
            </div>
          </div>
        </div>
      </section>

      <Footer />
      <WhatsAppFloatingBtn />
    </div>
  );
}
