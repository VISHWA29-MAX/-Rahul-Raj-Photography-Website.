"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import Image from "next/image";
import { usePathname } from "next/navigation";
import { Menu, X, MessageCircle, Calendar, ArrowRight } from "lucide-react";
import { siteConfig } from "@/data/siteConfig";

const navItems = [
  { name: "Home", href: "/" },
  { name: "About Us", href: "/about" },
  { name: "Portfolio", href: "/portfolio" },
  { name: "Services", href: "/services" },
  { name: "Packages", href: "/packages" },
  { name: "Films & Videos", href: "/films" },
  { name: "Book Now", href: "/book" },
  { name: "Contact", href: "/contact" },
];

export default function Navbar() {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const pathname = usePathname();

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const whatsappUrl = `https://wa.me/${siteConfig.whatsappNumber}?text=${encodeURIComponent(
    "Hello Rahul Raj Photography, I visited your website and would like to enquire about photography coverage for an upcoming event."
  )}`;

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled
          ? "bg-[#050505]/95 backdrop-blur-md border-b border-[#1E1E1E] shadow-2xl py-3"
          : "bg-gradient-to-b from-[#050505]/90 to-transparent py-5"
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between">
        {/* Brand Logo */}
        <Link href="/" className="relative z-10 flex items-center group">
          <div className="relative h-11 w-44 sm:h-12 sm:w-56 transition-transform duration-300 group-hover:scale-[1.02]">
            <Image
              src="/logo/logo.svg"
              alt="Rahul Raj Photography"
              fill
              priority
              className="object-contain object-left"
            />
          </div>
        </Link>

        {/* Desktop Nav Items */}
        <div className="hidden lg:flex items-center gap-7">
          {navItems.map((item) => {
            const isActive = pathname === item.href;
            return (
              <Link
                key={item.name}
                href={item.href}
                className={`text-sm tracking-wide transition-colors relative py-1 ${
                  isActive
                    ? "text-white font-medium"
                    : "text-[#BDBDBD] hover:text-white"
                }`}
              >
                {item.name}
                {isActive && (
                  <span className="absolute bottom-0 left-0 right-0 h-[2px] bg-[#E50914] rounded-full"></span>
                )}
              </Link>
            );
          })}
        </div>

        {/* Desktop Action Buttons */}
        <div className="hidden lg:flex items-center gap-3">
          <a
            href={whatsappUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-2 text-xs uppercase tracking-wider font-semibold px-3.5 py-2.5 rounded-full border border-[#2E2E2E] bg-[#111111] text-[#E0E0E0] hover:border-[#25D366] hover:text-[#25D366] transition-all"
            title="Chat on WhatsApp"
          >
            <MessageCircle className="w-4 h-4 text-[#25D366]" />
            <span>WhatsApp</span>
          </a>

          <Link
            href="/book"
            className="flex items-center gap-2 text-xs uppercase tracking-wider font-bold px-4 py-2.5 rounded-full bg-[#E50914] text-white hover:bg-[#C40812] transition-all shadow-lg shadow-[#E50914]/20 hover:shadow-[#E50914]/40"
          >
            <Calendar className="w-3.5 h-3.5" />
            <span>Book Your Event</span>
          </Link>
        </div>

        {/* Mobile Menu Button */}
        <div className="flex lg:hidden items-center gap-2">
          <a
            href={whatsappUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="p-2 rounded-full border border-[#2A2A2A] bg-[#111111] text-[#25D366]"
            aria-label="WhatsApp"
          >
            <MessageCircle className="w-4 h-4" />
          </a>
          <button
            onClick={() => setIsOpen(!isOpen)}
            className="p-2 rounded-lg text-[#BDBDBD] hover:text-white bg-[#111111] border border-[#262626]"
            aria-label="Toggle menu"
          >
            {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer */}
      {isOpen && (
        <div className="lg:hidden fixed inset-x-0 top-[70px] bg-[#0A0A0A]/98 backdrop-blur-xl border-b border-[#222222] px-6 py-8 shadow-2xl transition-all">
          <div className="flex flex-col space-y-4">
            {navItems.map((item) => {
              const isActive = pathname === item.href;
              return (
                <Link
                  key={item.name}
                  href={item.href}
                  onClick={() => setIsOpen(false)}
                  className={`text-base font-medium py-2 flex items-center justify-between border-b border-[#1A1A1A] ${
                    isActive ? "text-[#E50914]" : "text-[#BDBDBD] hover:text-white"
                  }`}
                >
                  <span>{item.name}</span>
                  <ArrowRight className="w-4 h-4 opacity-50" />
                </Link>
              );
            })}

            <div className="pt-4 flex flex-col gap-3">
              <Link
                href="/book"
                onClick={() => setIsOpen(false)}
                className="w-full py-3 rounded-xl bg-[#E50914] text-white text-center font-bold text-sm tracking-wide shadow-lg shadow-[#E50914]/30"
              >
                Book Your Event Now
              </Link>
              <a
                href={whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full py-3 rounded-xl bg-[#141414] border border-[#2A2A2A] text-white text-center font-medium text-sm flex items-center justify-center gap-2 text-[#25D366]"
              >
                <MessageCircle className="w-4 h-4" />
                <span>Chat on WhatsApp</span>
              </a>
            </div>
          </div>
        </div>
      )}
    </nav>
  );
}
